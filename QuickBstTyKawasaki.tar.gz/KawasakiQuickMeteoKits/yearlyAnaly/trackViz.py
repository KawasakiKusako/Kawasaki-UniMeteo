import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.io.shapereader import Reader
from matplotlib.patches import Patch
import os
from typing import Optional, Dict, List
import numpy as np

def load_typhoon_data(inputYear, typhoon_id, typhoon_name) -> Dict[str, any]:
    """
    读取台风CSV文件，提取数据并解析台风编号、名称，返回数据字典。
    """
    csv_file_path = f"yearlyAnaly/cache/TY-{inputYear}-DIVED/{typhoon_id}_{typhoon_name}.csv"
    if not os.path.exists(csv_file_path):
        raise FileNotFoundError(f"CSV file not found: {csv_file_path}")
    
    csv_header = ["TIME", "TYPE", "LAT", "LON", "PRESS", "WND", "OWD"]
    try:
        df = pd.read_csv(
            csv_file_path,
            header=0,
            names=csv_header,
            dtype={
                "TYPE": int,
                "LAT": float,
                "LON": float,
                "WND": float,
                "PRESS": float
            }
        )
    except Exception as e:
        raise ValueError(f"Failed to read CSV: {str(e)}")
    
    required_cols = ["TIME", "TYPE", "LAT", "LON", "WND"]
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise KeyError(f"Missing required columns: {', '.join(missing_cols)}")
    df = df.dropna(subset=["LAT", "LON"]).reset_index(drop=True)
    if len(df) < 2:
        raise ValueError(f"Insufficient valid data (only {len(df)} records)")
    
    # a. LAT LON 除以 10
    df["LAT"] = df["LAT"] / 10.0
    df["LON"] = df["LON"] / 10.0
    
    # b. 处理跨 180 度经线的情况（大于 180° 视为西经，转换为负值）
    # 注意：这里假设您的原始 LON > 1800 的数据点实际上是西经。
    # 如果 LON > 180 意味着数据点在西半球（如美洲），我们将其转换为 (-180, 180] 范围
    df.loc[df["LON"] > 180, "LON"] = df.loc[df["LON"] > 180, "LON"] - 360.0
    
    df["DATETIME"] = pd.to_datetime(df["TIME"], format="%Y%m%d%H")
    df["TIME_LABEL"] = df["DATETIME"].dt.strftime("%m-%d %H:00")
    
    type_intensity_map = {
        0: "TD- (Weak/Unknown)",
        1: "TD (Tropical Depression)",
        2: "TS (Tropical Storm)",
        3: "STS (Severe Tropical Storm)",
        4: "TY (Typhoon)",
        5: "STY (Strong Typhoon)",
        6: "SuperTY (Super Typhoon)",
        9: "Extratropical Cyclone" # 变性完成
    }
    df["INTENSITY"] = df["TYPE"].map(
        lambda x: type_intensity_map.get(x, f"Unknown (TYPE={x})")
    )

    file_name = os.path.basename(csv_file_path).replace(".csv", "")
    if "_" not in file_name:
        raise ValueError(f"Invalid CSV filename (need '编号_名称' format): {file_name}")
    ty_code, ty_name = file_name.split("_", 1)
    
    saveTyplotDir = f"typ_plots/{inputYear}/{typhoon_id}_{typhoon_name}/"
    shpDir = "extraRepo/SHP/china_SHP/nation/省界_Project.shp"
    return {
        "data": df,
        "ty_code": ty_code,
        "ty_name": ty_name,
        "saveTyplotDir": saveTyplotDir,
        "shpDir": shpDir
    }

def plot_typhoon_track(
    typhoon_dict: Dict[str, any],
    dpi: int = 300,
) -> None:

    # 提取数据和台风信息
    df = typhoon_dict["data"]
    ty_code = typhoon_dict["ty_code"]
    ty_name = typhoon_dict["ty_name"]
    save_dir = typhoon_dict["saveTyplotDir"]
    china_shp_path = typhoon_dict["shpDir"]
    idx_max_wnd = df["WND"].idxmax()
    data_max_wnd = df.loc[idx_max_wnd]
    idx_min_press = df["PRESS"].idxmin()
    data_min_press = df.loc[idx_min_press]

    min_lon_data, max_lon_data = df["LON"].min(), df["LON"].max()
    min_lat_data, max_lat_data = df["LAT"].min(), df["LAT"].max()
    
    lon_margin = 5  # 经度方向增加 5 度边距
    lat_margin = 5  # 纬度方向增加 5 度边距
    
    min_lon_cal = max(-180, min_lon_data - lon_margin)
    max_lon_cal = min(180, max_lon_data + lon_margin)
    min_lat_cal = max(-90, min_lat_data - lat_margin)
    max_lat_cal = min(90, max_lat_data + lat_margin)

    if abs(max_lon_cal - min_lon_cal) < 10:
        center_lon = (min_lon_cal + max_lon_cal) / 2
        min_lon_cal = center_lon - 5
        max_lon_cal = center_lon + 5
    if abs(max_lat_cal - min_lat_cal) < 10:
        center_lat = (min_lat_cal + max_lat_cal) / 2
        min_lat_cal = center_lat - 5
        max_lat_cal = center_lat + 5

    adaptive_extent = [min_lon_cal, max_lon_cal, min_lat_cal, max_lat_cal]
    center_lon_proj = (min_lon_data + max_lon_data) / 2
    
    plt.rcParams['font.sans-serif'] = ['Arial', 'SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(
        1, 1, 1,
        projection=ccrs.Mercator(central_longitude=center_lon_proj)
    )
    
    ax.set_extent(adaptive_extent, crs=ccrs.PlateCarree())
    ax.set_facecolor("#DEF4FF")  # Ocean color
    
    try:
        ax.add_feature(cfeature.LAND, facecolor="#DFDFDF")
        ax.coastlines(resolution='50m', linewidth=0.8, color='black')
    except Exception as e:
        print(f"Warning: Failed to load coastlines/land: {str(e)}")
    
    if china_shp_path and os.path.exists(china_shp_path):
        try:
            shp_feature = cfeature.ShapelyFeature(
                Reader(china_shp_path).geometries(),
                ccrs.PlateCarree(),
                facecolor='none',
                edgecolor="#797979",
                linewidth=1.0
            )
            ax.add_feature(shp_feature)
            print(f"Successfully loaded China boundary from SHP: {china_shp_path}")
        except Exception as e:
            print(f"Warning: Failed to load China SHP: {str(e)}")
    else:
        ax.add_feature(cfeature.BORDERS, linestyle=':', alpha=0.8, edgecolor='black')
        print("Warning: China SHP not found, use default borders instead")
    
    gl = ax.gridlines(
        crs=ccrs.PlateCarree(), draw_labels=True, linewidth=0.5, alpha=0.3,
        linestyle="--", color='black'
    )
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'fontsize': 9, 'color': 'black'}
    gl.ylabel_style = {'fontsize': 9, 'color': 'black'}
    
    intensity_style = {
        "TD- (Weak/Unknown)": ("#87CEEB", "o"),
        "TD (Tropical Depression)": ("#4169E1", "s"),
        "TS (Tropical Storm)": ("#FFD700", "^"),
        "STS (Severe Tropical Storm)": ("#FF8C00", "D"),
        "TY (Typhoon)": ("#FF4500", "p"),
        "STY (Strong Typhoon)": ("#DC143C", "*"),
        "SuperTY (Super Typhoon)": ("#8B0000", "X"),
        "Extratropical Cyclone": ("#9932CC", "P"),
        "Unknown (TYPE=?)": ("#696969", "x")
    }
    
    intensity_means = df.groupby("INTENSITY")["WND"].mean()
    unique_intensities = df["INTENSITY"].unique()

    ax.plot(df["LON"], df["LAT"], color='black', linewidth=3.0, linestyle='-',
            alpha=1.0, transform=ccrs.PlateCarree(), zorder=3, label="_nolegend_")
    ax.plot(df["LON"], df["LAT"], color='dimgray', linewidth=2.0, linestyle='-',
            alpha=0.8, transform=ccrs.PlateCarree(), zorder=4, label="_nolegend_")
    for intensity, group in df.groupby("INTENSITY"):
        color, marker = intensity_style.get(intensity, ("#696969", "x"))
        
        ax.scatter(
            group["LON"], group["LAT"],
            color=color, marker=marker,
            s=group["WND"] * 3,
            edgecolor="black", linewidth=0.5, alpha=0.9,
            transform=ccrs.PlateCarree(), zorder=5
        )

    ax.plot(
        df["LON"], df["LAT"],
        color='black', 
        linewidth=3.0, # 增加线宽
        linestyle='-',
        alpha=1.0, # 不透明
        transform=ccrs.PlateCarree(),
        zorder=3, # Zorder 3
        label="_nolegend_" # 不在默认图例中显示
    )

    ax.plot(
        df["LON"], df["LAT"],
        color='dimgray', 
        linewidth=2.0, 
        linestyle='-',
        alpha=0.8, 
        transform=ccrs.PlateCarree(),
        zorder=4, # Zorder 4
        label="_nolegend_"
    )

    for intensity, group in df.groupby("INTENSITY"):
        color, marker = intensity_style.get(
            intensity, ("#696969", "x")
        )
        
        ax.scatter(
            group["LON"], group["LAT"],
            color=color,
            marker=marker,
            s=group["WND"] * 3,  # 风速越大，点越大
            edgecolor="black",
            linewidth=0.5,
            alpha=0.9,
            transform=ccrs.PlateCarree(),
            zorder=5  # Zorder 5 (确保在路径线之上)
        )
    
    ax.text(
        df["LON"].iloc[0] + 0.3, df["LAT"].iloc[0] + 0.1,
        f"Start\nW:{df['WND'].iloc[0]:.1f} P:{df['PRESS'].iloc[0]:.0f}",
        fontsize=8, color='green', fontweight='bold',
        transform=ccrs.PlateCarree(), zorder=6
    )
    
    ax.text(
        df["LON"].iloc[-1] + 0.3, df["LAT"].iloc[-1] + 0.1,
        f"End\nW:{df['WND'].iloc[-1]:.1f} P:{df['PRESS'].iloc[-1]:.0f}",
        fontsize=8, color='red', fontweight='bold',
        transform=ccrs.PlateCarree(), zorder=6
    )

    # 每隔 N=3 个点进行标注（w/p
    interval = 3
    indices_to_label = np.arange(1, len(df) - 1, interval) 

    for idx in indices_to_label:
        lon, lat, wnd, press = df.loc[idx, ["LON", "LAT", "WND", "PRESS"]]
        label_text = f"W:{wnd:.1f}\nP:{press:.0f}"
        
        ax.text(
            lon + 0.3, lat + 0.1, 
            label_text,
            fontsize=7, color='navy', alpha=0.7,
            transform=ccrs.PlateCarree(), zorder=6
        )
    
    #最小气压点 (Min Press)
    ax.scatter(
        data_min_press["LON"], data_min_press["LAT"],
        color="#0059E9", marker='P', s=200, edgecolor="darkblue", linewidth=2.0,
        transform=ccrs.PlateCarree(), zorder=7, label="_nolegend_"
    )
    # 添加标注文字
    ax.text(
        data_min_press["LON"] - 0.5, data_min_press["LAT"] + 1.0,
        f"Min Press: {data_min_press['PRESS']:.0f} hPa",
        fontsize=10, color='dimgray', fontweight='bold', ha='right',
        transform=ccrs.PlateCarree(), zorder=7
    )

    # 最大风速点 (Max Wind)
    # 如果最小气压和最大风速点是同一个点，我们使用不同的标记和偏移量
    marker_wnd = 'X' if idx_max_wnd != idx_min_press else 'D'
    ax.scatter(
        data_max_wnd["LON"], data_max_wnd["LAT"],
        color="#FF7676", marker=marker_wnd, s=200, edgecolor="#BC0000", linewidth=2.0,
        transform=ccrs.PlateCarree(), zorder=7, label="_nolegend_"
    )
    # 添加标注文字
    ax.text(
        data_max_wnd["LON"] + 0.5, data_max_wnd["LAT"] - 1.0,
        f"Max Wind: {data_max_wnd['WND']:.1f} m/s",
        fontsize=10, color='red', fontweight='bold', ha='left',
        transform=ccrs.PlateCarree(), zorder=7
    )

    # 主标题
    main_title = (
        f"Typhoon {ty_code} {ty_name} - Historical Track Map\n"
        
    )
    ax.set_title(
        main_title,
        loc='left',
        fontsize=15,
        color='black',
        pad=17
    )
    
    # 副标题 
    ax.text(
        x=0.00, y=1.045,
        s=f"Historical Data: CMA Typhoon Center CDUT CMS @Kawasaki Kusako\nMax Wind: {data_max_wnd['WND']:.1f} m/s | Min Press: {data_min_press['PRESS']:.0f} hPa",
        transform=ax.transAxes, horizontalalignment='left',
        fontsize=10, color='dimgray', verticalalignment='top'
    )

    legend_elements = [
        Patch(
            facecolor=intensity_style.get(intensity, ("#696969", "x"))[0],
            edgecolor="black",
            label=f"{intensity} (Avg Wind: {intensity_means[intensity]:.1f} m/s)"
        )
        for intensity in unique_intensities
    ]
    
    legend_elements.append(
        Patch(facecolor='dimgray', edgecolor="black", label="Overall Track Line")
    )
    
    # 添加极值点图例
    legend_elements.append(
        Patch(facecolor='cyan', edgecolor='darkblue', label=f"Min Press ({data_min_press['PRESS']:.0f} hPa)")
    )
    legend_elements.append(
        Patch(facecolor='yellow', edgecolor='red', label=f"Max Wind ({data_max_wnd['WND']:.1f} m/s)")
    )
    # 设置图例自适应无遮挡
    ax.legend(
        handles=legend_elements,
        loc='lower left',
        fontsize=8,
        framealpha=0.9,
        edgecolor='black',
        facecolor='white'
    )
    
    plt.tight_layout()
    
    if save_dir is not None:
        os.makedirs(save_dir, exist_ok=True)
        img_filename = f"Typhoon_{ty_code}_{ty_name}_Track.png"
        img_path = os.path.join(save_dir, img_filename)
        plt.savefig(img_path, dpi=dpi, bbox_inches="tight", facecolor="white")
        print(f"Track map saved to: {os.path.abspath(img_path)}")
    
    plt.show()
    plt.close()
#================================== AI POWERED =======================================================================
def load_all_typhoon_data_for_year(inputYear: int) -> List[Dict[str, any]]:
    """
    读取指定年份下所有台风的CSV文件，返回一个包含所有台风数据的列表。
    """
    base_dir = f"yearlyAnaly/cache/TY-{inputYear}-DIVED/"
    all_typhoon_data = []

    if not os.path.isdir(base_dir):
        print(f"Error: Directory not found: {base_dir}")
        return all_typhoon_data

    # 遍历目录下的所有文件
    for filename in os.listdir(base_dir):
        if filename.endswith(".csv"):
            try:
                # 文件名格式应为 TYID_TYNAME.csv
                parts = filename.replace(".csv", "").split("_", 1)
                if len(parts) == 2:
                    typhoon_id = parts[0]
                    typhoon_name = parts[1]
                    
                    # 使用现有的 load_typhoon_data 函数处理单个文件
                    typhoon_dict = load_typhoon_data(inputYear, typhoon_id, typhoon_name)
                    all_typhoon_data.append(typhoon_dict)
                    
                else:
                    print(f"Warning: Skipping file with unexpected name format: {filename}")
            except Exception as e:
                # 忽略单个文件读取错误，继续处理下一个台风
                print(f"Warning: Failed to load data for {filename}. Error: {str(e)}")
                continue
                
    print(f"Successfully loaded data for {len(all_typhoon_data)} typhoons in {inputYear}.")
    return all_typhoon_data
def plot_all_typhoons_track(
    all_typhoon_data: List[Dict[str, any]],
    inputYear: int,
    dpi: int = 300
) -> None:
    """
    在一个图上绘制指定年份所有台风的轨迹。
    """
    if not all_typhoon_data:
        print("No typhoon data to plot.")
        return

    # 1. 计算自适应地图范围
    all_lons = pd.concat([d["data"]["LON"] for d in all_typhoon_data])
    all_lats = pd.concat([d["data"]["LAT"] for d in all_typhoon_data])
    
    min_lon_data, max_lon_data = all_lons.min(), all_lons.max()
    min_lat_data, max_lat_data = all_lats.min(), all_lats.max()
    
    lon_margin, lat_margin = 10, 10 # 扩大边距以容纳所有轨迹
    
    # 计算自适应范围 (与 plot_typhoon_track 中的逻辑相同)
    min_lon_cal = max(-180, min_lon_data - lon_margin)
    max_lon_cal = min(180, max_lon_data + lon_margin)
    min_lat_cal = max(-90, min_lat_data - lat_margin)
    max_lat_cal = min(90, max_lat_data + lat_margin)

    if abs(max_lon_cal - min_lon_cal) < 30: # 进一步确保大范围地图的最小跨度
        center_lon = (min_lon_cal + max_lon_cal) / 2
        min_lon_cal = center_lon - 15
        max_lon_cal = center_lon + 15
    if abs(max_lat_cal - min_lat_cal) < 20:
        center_lat = (min_lat_cal + max_lat_cal) / 2
        min_lat_cal = center_lat - 10
        max_lat_cal = center_lat + 10

    adaptive_extent = [min_lon_cal, max_lon_cal, min_lat_cal, max_lat_cal]
    center_lon_proj = (min_lon_data + max_lon_data) / 2
    
    # 2. 初始化地图
    plt.rcParams['font.sans-serif'] = ['Arial', 'SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_subplot(
        1, 1, 1,
        projection=ccrs.Mercator(central_longitude=center_lon_proj)
    )
    
    ax.set_extent(adaptive_extent, crs=ccrs.PlateCarree())
    ax.set_facecolor("#DEF4FF")
    
    # 绘制地理要素
    try:
        ax.add_feature(cfeature.LAND, facecolor="#DFDFDF")
        ax.coastlines(resolution='50m', linewidth=0.8, color='black')
        ax.add_feature(cfeature.BORDERS, linestyle=':', alpha=0.8, edgecolor='black')
    except Exception as e:
        print(f"Warning: Failed to load geography: {str(e)}")
        
    gl = ax.gridlines(
        crs=ccrs.PlateCarree(), draw_labels=True, linewidth=0.5, alpha=0.3,
        linestyle="--", color='black'
    )
    gl.top_labels, gl.right_labels = False, False
    gl.xlabel_style = {'fontsize': 9, 'color': 'black'}
    gl.ylabel_style = {'fontsize': 9, 'color': 'black'}

    # 3. 绘制所有台风路径
    # 使用颜色映射来区分不同的台风
    colors = plt.cm.gist_rainbow(np.linspace(0, 1, len(all_typhoon_data)))
    
    for i, typhoon_dict in enumerate(all_typhoon_data):
        df = typhoon_dict["data"]
        ty_code = typhoon_dict["ty_code"]
        ty_name = typhoon_dict["ty_name"]
        color = colors[i]
        
        # 绘制路径线（细线，alpha较低，强调整体分布）
        ax.plot(
            df["LON"], df["LAT"],
            color=color,
            linewidth=1.5,
            linestyle='-',
            alpha=0.7,
            transform=ccrs.PlateCarree(),
            zorder=4,
            label=f"{ty_code} {ty_name}" # 用于图例
        )
        
        # 绘制起点（略大，圆形标记）
        ax.scatter(
            df["LON"].iloc[0], df["LAT"].iloc[0],
            color=color,
            marker='o',
            s=50,
            edgecolor="black",
            linewidth=0.5,
            transform=ccrs.PlateCarree(),
            zorder=5,
            label="_nolegend_"
        )

        # 标注台风编号
        ax.text(
            df["LON"].iloc[0] + 0.5, df["LAT"].iloc[0],
            ty_code,
            fontsize=8,
            color=color,
            fontweight='bold',
            transform=ccrs.PlateCarree(),
            zorder=6
        )

    # 4. 添加标题和图例
    main_title = f"All Typhoon Tracks in {inputYear}"
    ax.set_title(
        main_title,
        loc='left', fontsize=18, color='black', pad=20
    )
    
    ax.text(
        x=0.00, y=1.02, s="Data Source: CMA Typhoon Center @Kawasaki Kusako",
        transform=ax.transAxes, horizontalalignment='left',
        fontsize=10, color='dimgray', verticalalignment='top'
    )

    # 图例 (只包含台风编号和名称)
    ax.legend(
        loc='lower right',
        fontsize=8,
        framealpha=0.9,
        edgecolor='black',
        facecolor='white',
        ncol=2 # 分两列显示图例
    )
    
    # 5. 保存和显示
    save_dir_all = f"typ_plots/{inputYear}/"
    os.makedirs(save_dir_all, exist_ok=True)
    img_filename = f"All_Typhoon_Tracks_{inputYear}.png"
    img_path = os.path.join(save_dir_all, img_filename)
    
    plt.tight_layout()
    plt.savefig(img_path, dpi=dpi, bbox_inches="tight", facecolor="white")
    print(f"All tracks map saved to: {os.path.abspath(img_path)}")
    
    plt.show()
    plt.close()


#=========


if __name__ == "__main__":

    inputYear = 1994  # 台风年份
    typhoon_id = "9417"  # 台风编号
    typhoon_name = "Fred"  # 台风名称
    # CSV_FILE_PATH 变量已在 load_typhoon_data 内部生成，此处不需要再定义。
    #CHINA_SHP_PATH = "extraRepo/SHP/china_SHP/nation/省界_Project.shp"  # 中国省界SHP文件路径（可选，无则设为None）
    
    try:

        #print(f"Loading typhoon data for: {typhoon_id}_{typhoon_name}")
        typhoon_data = load_typhoon_data(inputYear, typhoon_id, typhoon_name) 
        #print(f"Loaded data for Typhoon {typhoon_data['ty_code']} {typhoon_data['ty_name']} ({len(typhoon_data['data'])} records)")

        #print("Generating typhoon track map...")
        # 修正：移除 'east_asia_extent' 参数，现在地图是自适应的
        plot_typhoon_track(
            typhoon_dict=typhoon_data,
            dpi=300
        )
        #print("Track map generated successfully!")
    except Exception as e:
        print(f"Error: {str(e)}")