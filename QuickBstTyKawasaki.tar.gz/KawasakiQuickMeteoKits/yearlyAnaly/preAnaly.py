import csv
import os
from typing import List, Dict

def generate_typhoon_csv_by_year(inputYear) -> None:
    """
    根据输入年份（如"1994"），从CMA BST台风路径原始数据中提取该年份的台风信息，
    按“台风编号+台风名称”拆分生成对应的CSV文件，CSV表头为TIME,TYPE,LAT,LON,PRESS,WND,OWD
    
    参数:
        inputYear: 字符串类型，需提取的台风年份，格式为"YYYY"（如"1994"）
    """
    # 1. 定义原始数据路径（需用户根据实际文件位置修改）
    # 注意：请将此处的"CH1994BST.txt"替换为实际的原始数据文件路径
    raw_data_path = f"dataSet/CH{inputYear}BST.txt"
    if not os.path.exists(raw_data_path):
        raise FileNotFoundError(f"原始数据文件未找到，请检查路径：{raw_data_path}")
    
    # 2. 读取原始数据并按台风分组
    typhoon_groups: Dict[str, List[List[str]]] = {}  # 键：台风标识（编号+名称），值：该台风的所有观测数据
    current_typhoon_id = ""  # 当前台风的标识（编号+名称）
    current_typhoon_data: List[List[str]] = []  # 当前台风的观测数据
    
    with open(raw_data_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue  # 跳过空行
            
            # 识别台风分隔行（以"66666 0000"开头）
            if line.startswith("66666 0000"):
                # 若存在上一个台风的数据，先保存到分组中
                if current_typhoon_id and current_typhoon_data:
                    typhoon_groups[current_typhoon_id] = current_typhoon_data
                
                # 解析当前分隔行中的台风信息
                parts = line.split()
                # 提取台风编号（第5个字段，如"9401"）和名称（第8个字段，如"Owen"）
                typhoon_no = parts[4] if len(parts) >= 5 else "unknown_no"
                typhoon_name = parts[7] if len(parts) >= 8 else "nameless"
                # 生成台风标识（编号+名称），处理无名称情况
                current_typhoon_id = f"{typhoon_no}_{typhoon_name}".replace(" ", "_")
                # 重置当前台风的观测数据列表
                current_typhoon_data = []
            
            # 识别观测数据行（以输入年份开头，如"1994"）
            elif line.startswith(inputYear):
                # 解析观测数据行的字段（按空格分割，忽略连续空格）
                data_parts = line.split()
                # 确保数据行至少包含6个核心字段（TIME到WND），不足则补空
                while len(data_parts) < 7:
                    data_parts.append("")
                
                # 提取对应字段（顺序：TIME,TYPE,LAT,LON,PRESS,WND,OWD）
                time = data_parts[0]
                type_ = data_parts[1]
                lat = data_parts[2]
                lon = data_parts[3]
                press = data_parts[4]
                wnd = data_parts[5]
                owd = data_parts[6] if len(data_parts) >= 7 else ""
                
                # 将当前观测数据添加到当前台风的列表中
                current_typhoon_data.append([time, type_, lat, lon, press, wnd, owd])
    
    # 保存最后一个台风的数据
    if current_typhoon_id and current_typhoon_data:
        typhoon_groups[current_typhoon_id] = current_typhoon_data
    
    # 3. 筛选输入年份的台风（台风编号前4位为年份后2位+01开始，如1994年台风编号为9401~9437）
    target_typhoon_prefix = inputYear[2:]  # 取年份后2位，如"1994"→"94"
    filtered_typhoons: Dict[str, List[List[str]]] = {}
    for typhoon_id, data in typhoon_groups.items():
        # 提取台风编号（标识的前5位，如"9401_Owen"→"9401"）
        typhoon_no = typhoon_id.split("_")[0]
        # 筛选出编号以目标年份前缀开头的台风
        if typhoon_no.startswith(target_typhoon_prefix):
            filtered_typhoons[typhoon_id] = data
    
    if not filtered_typhoons:
        print(f"未找到{inputYear}年的台风数据")
        return
    
    # 4. 创建输出文件夹（若不存在）
    output_dir = f"yearlyAnaly/cache/TY-{inputYear}-DIVED"
    os.makedirs(output_dir, exist_ok=True)
    print(f"输出文件夹已创建：{os.path.abspath(output_dir)}")
    
    # 5. 生成每个台风的CSV文件
    csv_header = ["TIME", "TYPE", "LAT", "LON", "PRESS", "WND", "OWD"]
    for typhoon_id, data in filtered_typhoons.items():
        # 生成CSV文件名（处理特殊字符，避免命名错误）
        csv_filename = f"{typhoon_id}.csv".replace("/", "_").replace("\\", "_")
        csv_path = os.path.join(output_dir, csv_filename)
        
        # 写入CSV文件
        with open(csv_path, "w", newline="", encoding="utf-8") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(csv_header)  # 写入表头
            writer.writerows(data)       # 写入观测数据
        
        print(f"已生成：{csv_filename}（共{len(data)}条观测记录）")
    
    print(f"\n{inputYear}年台风CSV文件生成完成！共{len(filtered_typhoons)}个台风，文件保存于：{os.path.abspath(output_dir)}")


# ------------------------------
# 使用示例（需用户根据实际情况修改）
# ------------------------------
if __name__ == "__main__":
    # 输入年份（格式为"YYYY"，如"1994"）
    target_year = "1994"
    # 调用函数生成CSV文件
    try:
        generate_typhoon_csv_by_year(target_year)
    except Exception as e:
        print(f"执行出错：{str(e)}")