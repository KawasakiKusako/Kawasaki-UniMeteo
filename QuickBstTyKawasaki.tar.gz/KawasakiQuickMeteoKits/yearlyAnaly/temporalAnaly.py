# cyclone_temporal_analysis.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import List, Dict, Optional
import os

# --- 辅助函数：提取时间分布所需的特征 ---
def _extract_temporal_features(all_typhoon_data: List[Dict[str, any]]) -> pd.DataFrame:
    """
    从所有台风路径数据中提取时间分布相关的关键特征：生成月份和生命期（小时）。
    """
    temporal_features = []
    
    for typhoon_dict in all_typhoon_data:
        df = typhoon_dict["data"]
        ty_code = typhoon_dict["ty_code"]
        
        # 提取生成月份
        start_month = df["DATETIME"].iloc[0].month
        
        # 提取生命期（小时）
        lifetime_seconds = (df["DATETIME"].iloc[-1] - df["DATETIME"].iloc[0]).total_seconds()
        lifetime_hours = lifetime_seconds / 3600
        
        temporal_features.append({
            "Typhoon_ID": ty_code,
            "Start_Month": start_month,
            "Lifetime_Hours": lifetime_hours
        })
        
    return pd.DataFrame(temporal_features)


# ====================================================================
# 主分析函数 1：月度生成频率分布
# ====================================================================
def plot_monthly_formation_distribution(
    all_typhoon_data: List[Dict[str, any]],
    inputYear: int,
    dpi: int = 300,
    save_dir: Optional[str] = None
) -> None:
    """
    绘制指定年份气旋（台风）的月度生成频率分布图。
    """
    if not all_typhoon_data:
        print("No typhoon data provided for monthly analysis.")
        return

    df_features = _extract_temporal_features(all_typhoon_data)
    
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['figure.dpi'] = dpi
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # 使用计数图（Countplot）显示每个月的台风数量
    sns.countplot(
        data=df_features,
        x='Start_Month',
        color='#4682B4',  # 钢铁蓝
        ax=ax
    )
    
    # 标注每个柱子的数量
    for p in ax.patches:
        ax.annotate(
            f'{int(p.get_height())}',
            (p.get_x() + p.get_width() / 2., p.get_height()),
            ha='center', va='center',
            xytext=(0, 5),
            textcoords='offset points',
            fontsize=10
        )
        
    ax.set_xticks(range(12))
    ax.set_xticklabels([f'{m}月' for m in range(1, 13)])
    ax.set_title(
        f'{inputYear} 年台风（气旋）月度生成频率分布 (总数: {len(df_features)})',
        fontsize=16,
        pad=15
    )
    ax.set_xlabel('生成月份', fontsize=12)
    ax.set_ylabel('生成气旋数量', fontsize=12)
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    
    if save_dir is None:
        save_dir = f"typ_plots/{inputYear}/Temporal_Analysis/"
        
    os.makedirs(save_dir, exist_ok=True)
    img_filename = f"Monthly_Formation_Distribution_{inputYear}.png"
    img_path = os.path.join(save_dir, img_filename)
    
    plt.savefig(img_path, dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.show()
    plt.close()
    print(f"Monthly distribution plot saved to: {os.path.abspath(img_path)}")


# ====================================================================
# 主分析函数 2：生命期分布分析
# ====================================================================
def plot_lifetime_distribution(
    all_typhoon_data: List[Dict[str, any]],
    inputYear: int,
    dpi: int = 300,
    save_dir: Optional[str] = None
) -> None:
    """
    绘制指定年份气旋（台风）的生命期（小时）分布图（核密度估计）。
    """
    if not all_typhoon_data:
        print("No typhoon data provided for lifetime analysis.")
        return

    df_features = _extract_temporal_features(all_typhoon_data)
    
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # 使用核密度估计图（KDE Plot）显示生命期分布
    sns.kdeplot(
        data=df_features,
        x='Lifetime_Hours',
        fill=True,
        linewidth=2,
        color='#FF8C00',  # 深橙色
        ax=ax
    )
    
    mean_lifetime = df_features['Lifetime_Hours'].mean()
    median_lifetime = df_features['Lifetime_Hours'].median()
    
    # 标注平均值和中位数
    ax.axvline(mean_lifetime, color='red', linestyle='--', linewidth=1.5, label=f'平均值: {mean_lifetime:.1f} hrs')
    ax.axvline(median_lifetime, color='green', linestyle='-.', linewidth=1.5, label=f'中位数: {median_lifetime:.1f} hrs')
    
    ax.set_title(
        f'{inputYear} 年台风（气旋）生命周期分布 (N={len(df_features)})',
        fontsize=16,
        pad=15
    )
    ax.set_xlabel('生命周期 (小时)', fontsize=12)
    ax.set_ylabel('密度', fontsize=12)
    ax.legend(loc='upper right')
    ax.grid(axis='x', linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    
    if save_dir is None:
        save_dir = f"typ_plots/{inputYear}/Temporal_Analysis/"
        
    os.makedirs(save_dir, exist_ok=True)
    img_filename = f"Lifetime_Distribution_{inputYear}.png"
    img_path = os.path.join(save_dir, img_filename)
    
    plt.savefig(img_path, dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.show()
    plt.close()
    print(f"Lifetime distribution plot saved to: {os.path.abspath(img_path)}")


# ====================================================================
# 主分析函数 3：时序协同热力图分析
# ====================================================================
def plot_temporal_coordination_heatmap(
    all_typhoon_data: List[Dict[str, any]],
    inputYear: int,
    dpi: int = 300,
    save_dir: Optional[str] = None
) -> None:
    """
    绘制气旋生成月份与生命期、最大强度之间的协同热力图。
    """
    if not all_typhoon_data:
        print("No typhoon data provided for temporal coordination analysis.")
        return

    # 1. 提取所有所需特征 (包括强度特征，因此需要重新提取或扩展辅助函数)
    # 我们扩展 _extract_temporal_features 来包含 Max_Wind
    
    # 临时重新定义一个包含 Max_Wind 的提取函数，以避免修改原文件中的函数定义
    def _extract_all_features_for_heatmap(all_typhoon_data: List[Dict[str, any]]) -> pd.DataFrame:
        features = []
        for typhoon_dict in all_typhoon_data:
            df = typhoon_dict["data"]
            lifetime_seconds = (df["DATETIME"].iloc[-1] - df["DATETIME"].iloc[0]).total_seconds()
            
            features.append({
                "Typhoon_ID": typhoon_dict["ty_code"],
                "Start_Month": df["DATETIME"].iloc[0].month,
                "Lifetime_Hours": lifetime_seconds / 3600,
                "Max_Wind": df["WND"].max()
            })
        return pd.DataFrame(features)
        
    df_features = _extract_all_features_for_heatmap(all_typhoon_data)
    
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(18, 7))
    plt.subplots_adjust(wspace=0.3)

    # ----------------------------------------------------
    # 热力图 A: 月份 vs. 平均生命期 (Lifetime)
    # ----------------------------------------------------
    # 计算 月份 vs. 平均生命期
    heatmap_data_life = df_features.groupby('Start_Month')['Lifetime_Hours'].mean().reset_index()
    heatmap_data_life = heatmap_data_life.rename(columns={'Lifetime_Hours': 'Avg_Lifetime_Hours'})
    heatmap_data_life['Start_Month'] = heatmap_data_life['Start_Month'].astype(int)
    
    # 将数据转换成适合热力图的矩阵（这里只有一列，所以我们用一个技巧）
    heatmap_matrix_life = heatmap_data_life.set_index('Start_Month').transpose()
    
    sns.heatmap(
        heatmap_matrix_life,
        annot=True,
        fmt=".1f",
        cmap="YlGnBu", # 黄绿蓝渐变
        cbar_kws={'label': '平均生命周期 (小时)'},
        linewidths=.5,
        linecolor='black',
        ax=axes[0]
    )
    
    axes[0].set_title(f'{inputYear} 年：气旋生成月份 vs. 平均生命周期', fontsize=14)
    axes[0].set_xlabel('生成月份', fontsize=12)
    axes[0].set_ylabel('指标', fontsize=12)
    axes[0].set_yticklabels(['Avg Lifetime'], rotation=0)

    # ----------------------------------------------------
    # 热力图 B: 月份 vs. 平均最大风速 (Max Wind)
    # ----------------------------------------------------
    # 计算 月份 vs. 平均最大风速
    heatmap_data_wind = df_features.groupby('Start_Month')['Max_Wind'].mean().reset_index()
    heatmap_data_wind = heatmap_data_wind.rename(columns={'Max_Wind': 'Avg_Max_Wind_m_s'})
    heatmap_data_wind['Start_Month'] = heatmap_data_wind['Start_Month'].astype(int)
    
    heatmap_matrix_wind = heatmap_data_wind.set_index('Start_Month').transpose()
    
    sns.heatmap(
        heatmap_matrix_wind,
        annot=True,
        fmt=".1f",
        cmap="OrRd", # 橙红渐变
        cbar_kws={'label': '平均最大风速 (m/s)'},
        linewidths=.5,
        linecolor='black',
        ax=axes[1]
    )
    
    axes[1].set_title(f'{inputYear} 年：气旋生成月份 vs. 平均最大风速', fontsize=14)
    axes[1].set_xlabel('生成月份', fontsize=12)
    axes[1].set_ylabel('指标', fontsize=12)
    axes[1].set_yticklabels(['Avg Max Wind'], rotation=0)

    # ----------------------------------------------------
    # 3. 保存和显示
    # ----------------------------------------------------
    if save_dir is None:
        save_dir = f"typ_plots/{inputYear}/Temporal_Analysis/"
        
    os.makedirs(save_dir, exist_ok=True)
    img_filename = f"Temporal_Coordination_Heatmap_{inputYear}.png"
    img_path = os.path.join(save_dir, img_filename)
    plt.rcParams['figure.dpi'] = dpi
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.suptitle(
        f"{inputYear} 年气旋生成时间与生命期/强度协同性分析",
        fontsize=18,
        y=1.02
    )
    plt.tight_layout(rect=[0, 0, 1, 0.98])
    
    plt.savefig(img_path, dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.show()
    plt.close()
    print(f"Temporal coordination heatmap saved to: {os.path.abspath(img_path)}")