# yearlyAnaly/spatiotemporal_analysis.py

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from typing import List, Dict, Tuple
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from matplotlib.patches import Patch
import os

# --- 1. 特征提取函数 ---
def extract_path_features(all_typhoon_data: List[Dict[str, any]]) -> Tuple[pd.DataFrame, List[str]]:
    """
    从所有台风路径数据中提取用于协同演变分析的关键特征。
    返回特征DataFrame和用于聚类的数值特征列名列表。
    """
    feature_list = []
    
    for typhoon_dict in all_typhoon_data:
        df = typhoon_dict["data"]
        ty_code = typhoon_dict["ty_code"]
        
        # 1. 空间特征
        avg_lon = df["LON"].mean()
        avg_lat = df["LAT"].mean()
        lon_span = df["LON"].max() - df["LON"].min()
        lat_span = df["LAT"].max() - df["LAT"].min()
        
        # 2. 时间特征
        lifetime_hours = (df["DATETIME"].iloc[-1] - df["DATETIME"].iloc[0]).total_seconds() / 3600
        start_month = df["DATETIME"].iloc[0].month
        
        # 3. 强度特征
        max_wnd = df["WND"].max()
        min_press = df["PRESS"].min()
        avg_wnd = df["WND"].mean()
        
        feature_list.append({
            "Typhoon_ID": ty_code,
            "Avg_Lon": avg_lon,
            "Avg_Lat": avg_lat,
            "Lon_Span": lon_span,
            "Lat_Span": lat_span,
            "Lifetime_Hours": lifetime_hours,
            "Start_Month": start_month,
            "Max_Wind": max_wnd,
            "Min_Press": min_press,
            "Avg_Wind": avg_wnd
        })
        
    features_df = pd.DataFrame(feature_list)
    # 移除 Start_Month, Typhoon_ID 等非数值列用于聚类
    numeric_features = features_df.drop(columns=["Typhoon_ID", "Start_Month"]).columns.tolist()
    
    return features_df, numeric_features

# --- 2. 聚类与演变分析函数 ---
def analyze_co_evolution(
    all_typhoon_data: List[Dict[str, any]],
    inputYear: int,
    n_clusters: int = 4, # 预设分为4类路径
    dpi: int = 300
) -> pd.DataFrame:
    """
    执行基于特征的聚类分析，识别不同的时空演变模式，并可视化结果。
    返回聚类群组的特征摘要DataFrame。
    """
    print(f"--- Starting Spatio-Temporal Co-evolution Analysis for {inputYear} (K={n_clusters}) ---")
    
    # 1. 特征提取
    features_df, numeric_features = extract_path_features(all_typhoon_data)
    X = features_df[numeric_features]
    
    if len(X) < n_clusters:
        print(f"Error: Number of typhoons ({len(X)}) is less than requested clusters ({n_clusters}). Aborting analysis.")
        return pd.DataFrame(), pd.DataFrame()
    
    # 2. 数据标准化
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # 3. K-Means 聚类
    print(f"Applying K-Means clustering with k={n_clusters}...")
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    features_df["Cluster"] = kmeans.fit_predict(X_scaled)
    
    # 4. 分析聚类结果
    cluster_summary = features_df.groupby("Cluster")[numeric_features].mean().round(2)
    print("\n--- Cluster Characteristics (Mean Values) ---")
    print(cluster_summary)

    # 5. 可视化聚类结果
    
    # a. 计算自适应地图范围
    all_lons = pd.concat([d["data"]["LON"] for d in all_typhoon_data])
    all_lats = pd.concat([d["data"]["LAT"] for d in all_typhoon_data])
    min_lon_data, max_lon_data = all_lons.min(), all_lons.max()
    min_lat_data, max_lat_data = all_lats.min(), all_lats.max()
    
    lon_margin, lat_margin = 10, 10
    min_lon_cal = max(-180, min_lon_data - lon_margin)
    max_lon_cal = min(180, max_lon_data + lon_margin)
    min_lat_cal = max(-90, min_lat_data - lat_margin)
    max_lat_cal = min(90, max_lat_data + lat_margin)
    
    # 确保最小范围
    if abs(max_lon_cal - min_lon_cal) < 30: 
        min_lon_cal = (min_lon_cal + max_lon_cal) / 2 - 15
        max_lon_cal = (min_lon_cal + max_lon_cal) / 2 + 15
    if abs(max_lat_cal - min_lat_cal) < 20:
        min_lat_cal = (min_lat_cal + max_lat_cal) / 2 - 10
        max_lat_cal = (min_lat_cal + max_lat_cal) / 2 + 10
        
    adaptive_extent = [min_lon_cal, max_lon_cal, min_lat_cal, max_lat_cal]
    center_lon_proj = (min_lon_data + max_lon_data) / 2

    # b. 初始化地图
    plt.rcParams['font.sans-serif'] = ['Arial', 'SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.Mercator(central_longitude=center_lon_proj))
    
    ax.set_extent(adaptive_extent, crs=ccrs.PlateCarree())
    ax.set_facecolor("#DEF4FF")
    
    try:
        ax.add_feature(cfeature.LAND, facecolor="#DFDFDF")
        ax.coastlines(resolution='50m', linewidth=0.8, color='black')
        ax.add_feature(cfeature.BORDERS, linestyle=':', alpha=0.8, edgecolor='black')
    except Exception as e:
        print(f"Warning: Failed to load geography: {str(e)}")
        
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True, linewidth=0.5, alpha=0.3, linestyle="--", color='black')
    gl.top_labels, gl.right_labels = False, False
    gl.xlabel_style = {'fontsize': 9, 'color': 'black'}
    gl.ylabel_style = {'fontsize': 9, 'color': 'black'}

    # c. 绘制路径
    cmap = plt.cm.get_cmap('Spectral', n_clusters)
    typhoon_cluster_map = features_df.set_index("Typhoon_ID")["Cluster"].to_dict()
    legend_handles = []
    
    for i, typhoon_dict in enumerate(all_typhoon_data):
        df = typhoon_dict["data"]
        ty_code = typhoon_dict["ty_code"]
        cluster = typhoon_cluster_map.get(ty_code, -1)
        
        if cluster != -1:
            color = cmap(cluster)
            label_text = f"Cluster {cluster}"
            
            # 绘制路径线
            # 仅在第一次绘制该 Cluster 时添加 label，用于图例
            is_new_cluster = not any(h.get_label() == label_text for h in legend_handles)
            
            line, = ax.plot(
                df["LON"], df["LAT"],
                color=color,
                linewidth=2.0,
                linestyle='-',
                alpha=0.7,
                transform=ccrs.PlateCarree(),
                zorder=4,
                label=label_text if is_new_cluster else "_nolegend_"
            )
            
            if is_new_cluster:
                 legend_handles.append(line)
                
            # 标注台风编号 (靠近起点)
            ax.text(
                df["LON"].iloc[0], df["LAT"].iloc[0] + 0.5,
                f"{ty_code}",
                fontsize=8,
                color=color,
                fontweight='bold',
                transform=ccrs.PlateCarree(),
                zorder=6
            )
    
    # 6. 添加标题和图例
    ax.set_title(
        f"Spatio-Temporal Co-evolution Analysis of Typhoons in {inputYear} (K={n_clusters} Clusters)",
        loc='left', fontsize=18, color='black', pad=20
    )
    
    ax.text(
        x=0.00, y=1.03, s="Method: K-Means Clustering on Path Features (Lon/Lat/Span/Lifetime/Intensity)",
        transform=ax.transAxes, horizontalalignment='left',
        fontsize=10, color='dimgray', verticalalignment='top'
    )

    ax.legend(
        handles=legend_handles,
        title="Path Clusters",
        loc='lower right',
        fontsize=10,
        framealpha=0.9,
        edgecolor='black',
        facecolor='white',
        ncol=1
    )
    
    # 7. 保存和显示
    save_dir_all = f"typ_plots/{inputYear}/Analysis/"
    os.makedirs(save_dir_all, exist_ok=True)
    img_filename = f"Co_evolution_K{n_clusters}_{inputYear}.png"
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir_all, img_filename), dpi=dpi, bbox_inches="tight", facecolor="white")
    
    plt.show()
    plt.close()
    print("--- Analysis Plot Saved ---")
    
    return features_df, cluster_summary

# 导入新的依赖
from scipy import stats
import seaborn as sns

def plot_cluster_distribution_analysis(
    features_df: pd.DataFrame,
    inputYear: int,
    n_clusters: int,
    dpi: int = 300
) -> None:
    """
    对聚类结果进行深入分析，可视化和检验不同聚类群组在时间（月份）和强度上的分布差异。
    """
    print("\n--- Starting Distribution and Statistical Analysis ---")
    
    # 1. 初始化绘图设置
    plt.rcParams['font.sans-serif'] = ['Arial', 'SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(16, 12))
    plt.subplots_adjust(hspace=0.4, wspace=0.3)
    
    # 获取聚类群组列表
    clusters = sorted(features_df['Cluster'].unique())
    
    # ----------------------------------------------------
    # Plot 1: 时间演变分析 - 台风生成月份分布
    # ----------------------------------------------------
    ax1 = axes[0, 0]
    sns.histplot(
        data=features_df,
        x='Start_Month',
        hue='Cluster',
        multiple='dodge',
        bins=np.arange(0.5, 13.5, 1), # 确保月份是整数且清晰
        palette='Spectral',
        ax=ax1,
        kde=True,
        legend=False # 统一使用右侧的图例
    )
    ax1.set_xticks(range(1, 13))
    ax1.set_xticklabels([f'{m}月' for m in range(1, 13)])
    ax1.set_title(f'Monthly Distribution of Typhoon Formation by Cluster (Year {inputYear})', fontsize=14)
    ax1.set_xlabel('Formation Month')
    ax1.set_ylabel('Count (Number of Typhoons)')
    
    # ----------------------------------------------------
    # Plot 2: 强度协同分析 - 最大风速（Max_Wind）箱线图
    # ----------------------------------------------------
    ax2 = axes[0, 1]
    sns.boxplot(
        data=features_df,
        x='Cluster',
        y='Max_Wind',
        palette='Spectral',
        ax=ax2
    )
    ax2.set_title('Max Wind Speed Distribution by Cluster', fontsize=14)
    ax2.set_xlabel('Cluster ID')
    ax2.set_ylabel('Max Wind Speed (m/s)')
    
    # ----------------------------------------------------
    # Plot 3: 空间中心分析 - 平均经纬度散点图
    # ----------------------------------------------------
    # 展示聚类中心在地理空间上的分布
    ax3 = axes[1, 0]
    cluster_centers = features_df.groupby('Cluster')[['Avg_Lon', 'Avg_Lat']].mean()
    sns.scatterplot(
        data=features_df,
        x='Avg_Lon',
        y='Avg_Lat',
        hue='Cluster',
        palette='Spectral',
        s=50,
        alpha=0.6,
        ax=ax3
    )
    ax3.scatter(
        cluster_centers['Avg_Lon'],
        cluster_centers['Avg_Lat'],
        marker='*',
        s=500,
        color='black',
        label='Cluster Center',
        zorder=10
    )
    ax3.set_title('Average Spatial Center of Path by Cluster', fontsize=14)
    ax3.set_xlabel('Average Longitude (deg)')
    ax3.set_ylabel('Average Latitude (deg)')
    
    # ----------------------------------------------------
    # Plot 4: 统计检验结果 (ANOVA)
    # ----------------------------------------------------
    ax4 = axes[1, 1]
    
    # 执行单因素方差分析 (ANOVA)
    # 检验不同聚类群组的 Max_Wind 平均值是否显著不同
    max_wind_by_cluster = [features_df['Max_Wind'][features_df['Cluster'] == c] for c in clusters]
    f_stat, p_value = stats.f_oneway(*max_wind_by_cluster)

    # 绘制结果文本
    ax4.text(
        0.5, 0.9, 
        'Statistical Test: One-way ANOVA', 
        fontsize=12, 
        fontweight='bold', 
        ha='center', 
        va='top'
    )
    ax4.text(
        0.5, 0.7, 
        f'Variable: Max Wind Speed (m/s)', 
        fontsize=11, 
        ha='center', 
        va='top'
    )
    ax4.text(
        0.5, 0.5, 
        f'F-statistic: {f_stat:.2f}', 
        fontsize=14, 
        fontweight='bold', 
        ha='center', 
        va='top', 
        color='navy'
    )
    ax4.text(
        0.5, 0.3, 
        f'P-value: {p_value:.5f}', 
        fontsize=14, 
        fontweight='bold', 
        ha='center', 
        va='top', 
        color='red' if p_value < 0.05 else 'green'
    )
    
    if p_value < 0.05:
        significance = "RESULT: Significant difference between clusters (P < 0.05)"
    else:
        significance = "RESULT: No significant difference found (P >= 0.05)"
        
    ax4.text(0.5, 0.1, significance, fontsize=10, ha='center', va='top')
    
    ax4.axis('off') # 隐藏坐标轴
    
    # ----------------------------------------------------
    # 5. 保存和显示
    # ----------------------------------------------------
    save_dir_all = f"typ_plots/{inputYear}/Analysis/"
    # 确保保存路径存在
    os.makedirs(save_dir_all, exist_ok=True)
    img_filename = f"Distribution_Analysis_K{n_clusters}_{inputYear}.png"
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir_all, img_filename), dpi=dpi, bbox_inches="tight", facecolor="white")
    
    plt.show()
    plt.close()
    print("--- Distribution Analysis Plot Saved ---")