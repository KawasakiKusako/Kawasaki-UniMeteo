# -*- coding: utf-8 -*-
"""
ERA5 SWEAT plotting script
- 保留原绘图框架
- 移除除风羽外的其它数值绘图
- 计算 Td850（由 T & q）并计算 SWEAT，绘制 SWEAT contourf（红-黄高值）
"""

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import cartopy.io.shapereader as shpreader
import numpy as np
import os
import matplotlib.colors as mcolors
from datetime import datetime, timedelta

# ---------- 辅助物理/气象函数 ----------
def calc_dewpoint_from_T_q(T_K, q, p_hPa):
    """
    根据温度（K）和比湿 q (kg/kg) 估算露点温度 Td (°C)。
    公式：
      e = (q * p) / (0.622 + 0.378 q)   [hPa]
      Td = (243.5 * ln(e/6.112)) / (17.67 - ln(e/6.112))
    参数可以是 numpy 数组或 xarray DataArray（返回同维度）
    """
    # 防止除零/负值
    q_arr = np.array(q)
    T_arr = np.array(T_K)
    p = float(p_hPa)

    e = (q_arr * p) / (0.622 + 0.378 * q_arr)  # hPa
    e = np.maximum(e, 0.01)  # 避免 log(<=0)

    ln_e = np.log(e / 6.112)
    Td = (243.5 * ln_e) / (17.67 - ln_e)  # °C

    return Td


def calc_total_totals(T850_C, Td850_C, T500_C):
    """
    Total Totals (TT) index (°C) 常用表示：
      TT = (T850 - T500) + (Td850 - T500) = T850 + Td850 - 2*T500
    输入均为摄氏度
    """
    return T850_C + Td850_C - 2.0 * T500_C


def wind_speed(u, v):
    return np.sqrt(u**2 + v**2)


def wind_dir(u, v):
    """
    返回风向角（弧度）。使用 arctan2(u, v) 以保证方向角与气象风向运算一致（用于 sin(d500-d850)）。
    这里的定义会与后续差值用于 sin，单位为弧度。
    """
    return np.arctan2(u, v)


def calc_sweat_generic(T850_K, q850, p850,
                       T500_K,
                       u850, v850,
                       u500, v500):
    """
    计算 SWEAT 指数（以文中公式为准）
      SWEAT = 12 * Td850 + 20 * (TT - 49) + 2 * v850 + v500 + 125 * (sin(d500 - d850) + 0.2)
    参数：
      T850_K, T500_K: 温度（K）
      q850: 850hPa 比湿 (kg/kg)
      p850: 850 （hPa）
      u/v: m/s
    返回：SWEAT 数值（同维度 numpy array）
    """
    # 转换为 numpy arrays
    T850_K_a = np.array(T850_K)
    T500_K_a = np.array(T500_K)
    q850_a = np.array(q850)
    u850_a = np.array(u850)
    v850_a = np.array(v850)
    u500_a = np.array(u500)
    v500_a = np.array(v500)

    # Td850 (°C)
    Td850 = calc_dewpoint_from_T_q(T850_K_a, q850_a, p850)

    # 温度转换为 ℃
    T850_C = T850_K_a - 273.15
    T500_C = T500_K_a - 273.15

    # TT 指数 (°C)
    TT = calc_total_totals(T850_C, Td850, T500_C)

    # 风速
    V850 = wind_speed(u850_a, v850_a)
    V500 = wind_speed(u500_a, v500_a)

    # 风向弧度
    d850 = wind_dir(u850_a, v850_a)
    d500 = wind_dir(u500_a, v500_a)

    SWEAT = (12.0 * Td850
             + 20.0 * (TT - 49.0)
             + 2.0 * V850
             + V500
             + 125.0 * (np.sin(d500 - d850) + 0.2)
            )

    return SWEAT


# ---------- 绘图函数（替换原 _draw_single_plot） ----------
def _draw_single_plot(ds, time_index, inputYear, typhoon_name):
    """
    绘制单个时次图：仅绘制 850hPa 风羽 与 SWEAT 指数（contourf）
    保留原有地图框架 / shapefile / 南海小图 / 保存逻辑 等
    """
    CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/nation/省界_Project.shp'
    SOUTH_CHINA_SEA_SHP = 'extraRepo/SHP/china_SHP/southSea/南海诸岛及其它岛屿.shp'
    EAST_ASIA_EXTENT = [70, 140, 15, 55]  # [lon_min, lon_max, lat_min, lat_max]

    data_time_str = ds['time'].isel(time=time_index).dt.strftime('%Y/%m/%d %HZ').item()

    # 选取区域子集（注意纬度顺序）
    data_subset = ds.isel(time=time_index).sel(
        latitude=slice(EAST_ASIA_EXTENT[3], EAST_ASIA_EXTENT[2]),
        longitude=slice(EAST_ASIA_EXTENT[0], EAST_ASIA_EXTENT[1])
    )

    # --- 1. 变量选择（若变量不存在，直接报错返回） ---
    try:
        # 850 hPa
        T850 = data_subset['t'].sel(pressure_level=850, method='nearest')  # K
        q850 = data_subset['q'].sel(pressure_level=850, method='nearest')  # kg/kg
        U850 = data_subset['u'].sel(pressure_level=850, method='nearest')
        V850 = data_subset['v'].sel(pressure_level=850, method='nearest')

        # 500 hPa
        T500 = data_subset['t'].sel(pressure_level=500, method='nearest')
        U500 = data_subset['u'].sel(pressure_level=500, method='nearest')
        V500 = data_subset['v'].sel(pressure_level=500, method='nearest')

    except KeyError as e:
        print(f"Error: 变量选择失败: {e}")
        return

    # --- 2. 计算 SWEAT ---
    # 将 xarray DataArray 转为 numpy array（按经纬顺序：lat x lon）
    SWEAT = calc_sweat_generic(
        T850_K=T850.values,
        q850=q850.values,
        p850=850.0,
        T500_K=T500.values,
        u850=U850.values,
        v850=V850.values,
        u500=U500.values,
        v500=V500.values
    )

    # SWEAT 可能含 nan/inf，做掩膜
    SWEAT = np.where(np.isfinite(SWEAT), SWEAT, np.nan)

    # --- 3. 绘图：保留地图框架 ---
    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.Mercator(central_longitude=105))
    ax.set_extent(EAST_ASIA_EXTENT, crs=ccrs.PlateCarree())
    ax.set_facecolor("#B3E6FF")

    # map features
    try:
        ax.add_feature(cfeature.LAND, facecolor="#DFDFDF")
        ax.coastlines(resolution='50m', linewidth=0.8, color='k')
    except Exception:
        pass

    # China boundary
    if os.path.exists(CHINA_BOUNDARY_SHP):
        try:
            reader = shpreader.Reader(CHINA_BOUNDARY_SHP)
            for geometry in reader.geometries():
                ax.add_geometries([geometry], ccrs.PlateCarree(),
                                  facecolor='none', edgecolor="#797979", linewidth=1.0)
        except Exception as e:
            print(f"!!! 警告: 读取国标 Shapefile 失败: {e}")
    else:
        ax.add_feature(cfeature.BORDERS, linestyle=':', alpha=0.8, edgecolor='k')

    # gridlines
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                      linewidth=0.5, color="#A9A9A9", alpha=0.5, linestyle='--')
    gl.top_labels = False
    gl.right_labels = False
    gl.x_inline = False
    gl.xlabel_style = {'size': 10, 'color': "#000000"}
    gl.ylabel_style = {'size': 10, 'color': "#000000"}
    
# --- 4. 绘制 SWEAT（contourf）: 分段连续渐变色带（完全可运行版） ---

    import matplotlib.colors as mcolors

    # 1) 连续色带的 Hex 点（蓝→绿→黄→红→紫→浅红）
    hex_colors = [
        "#00379D",  # 蓝色 (0)
        "#388EFF",#25
        "#1FE9FF",#(50)
        "#61F024",  # 绿色 (75)
        "#309800",#100
        "#FFFB00",  # 黄色 (150)
        "#FFB700",  # 红色 (200)
        "#FF7700",#250
        "#FF0000",#300
        "#8000B2",  # 紫色 (400)
        "#EFC6FF",  # 浅红色 (500)
    ]

    # 2) 建立一个平滑的连续 colormap
    sweat_cmap = mcolors.LinearSegmentedColormap.from_list("sweat_continuous", hex_colors, N=24)

    # 让 colormap 对 NaN/掩码点透明（set_bad）
    # 注意：RGBA 中最后一位为 alpha，0 表示完全透明
    sweat_cmap.set_bad((0.0, 0.0, 0.0, 0.0))

    # 3) 掩膜：SWEAT < 0 的值全部掩掉（以后 contourf 不会绘制这些点）
    #    这样就实现了“0 以下透明”的效果
    SWEAT_masked = np.ma.masked_where(SWEAT < 0, SWEAT)

    # 4) 绘制区间与 levels（从 0 到 600 连续）
    vmin, vmax = 0.0, 600.0
    levels = np.linspace(vmin, vmax, 200)  # 越密越平滑

    # 5) 经纬度（确保与 SWEAT 的维度对齐）
    lons = data_subset['longitude'].values
    lats = data_subset['latitude'].values

    # 6) 用 contourf 绘制（带掩膜的连续色带）
    cf = ax.contourf(
        lons, lats, SWEAT_masked,
        levels=levels,
        cmap=sweat_cmap,
        vmin=vmin, vmax=vmax,
        extend='both',
        transform=ccrs.PlateCarree(),
        alpha=0.92
    )

    # 7) colorbar：显示 0-600 的连续色带，刻度按需调整
    cbar = fig.colorbar(
        cf, ax=ax, orientation='vertical',
        pad=0.03, shrink=0.7,
        ticks=[0, 25, 50, 75, 100, 150, 200, 250, 300, 400, 500, 600],
        label='SWEAT Index'
    )
    cbar.ax.tick_params(labelsize=9)


    # --- 5. 绘制 850hPa 风羽（保留） ---
    skip = 3
    try:
        ax.quiver(U850['longitude'].values[::skip], U850['latitude'].values[::skip],
                  U850.values[::skip, ::skip], V850.values[::skip, ::skip],
                  color='white',
                  scale=1000, width=0.0012, headwidth=3.5, headlength=4.5,
                  transform=ccrs.PlateCarree())
    except Exception as e:
        print(f"Warning: 绘制风羽失败: {e}")

    # --- 6. 南海小图（保留） ---
    '''
    draw_scs_features = os.path.exists(SOUTH_CHINA_SEA_SHP)
    ax_scs = fig.add_axes([0.13, 0.2, 0.09, 0.18], projection=ccrs.PlateCarree())
    ax_scs.set_extent([105, 122, 0, 25], crs=ccrs.PlateCarree())
    ax_scs.axis('off')
    ax_scs.set_frame_on(True)
    ax_scs.patch.set_edgecolor('black')
    ax_scs.patch.set_linewidth(1.5)
    ax_scs.add_feature(cfeature.LAND, facecolor='lightgray')
    ax_scs.add_feature(cfeature.OCEAN, facecolor='white')
    ax_scs.coastlines(resolution='50m', linewidth=0.5, color='k')

    if draw_scs_features:
        try:
            reader = shpreader.Reader(SOUTH_CHINA_SEA_SHP)
            for geometry in reader.geometries():
                ax_scs.add_geometries([geometry], ccrs.PlateCarree(),
                                      facecolor='none', edgecolor='k', linewidth=0.5)
        except Exception:
            pass
    '''

    # --- 7. 标题与副标题（保留样式） ---
    ax.set_title(
        f"ERA-5 SWEAT Index & 850hPa Wind ",
        loc='left',
        fontsize=11,
        color='black',
        pad=20
    )
    ax.text(
        x=0.00,
        y=1.03,
        s=f"Historical Data : {data_time_str} valid at {data_time_str}  CDUT CMS @Kawasaki Kusako ",
        transform=ax.transAxes,
        horizontalalignment='left',
        fontsize=9,
        color='dimgray',
        verticalalignment='top'
    )

    # --- 8. 保存图像（保留原存储路径结构） ---
    out_dir = f"era_plots/{inputYear}_{typhoon_name}/TYPE-SWEAT"
    if not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    time_for_filename = ds['time'].isel(time=time_index).dt.strftime('%Y%m%d%H').item()
    output_filename = f"{out_dir}/TYPE-SWEAT-{inputYear}_{typhoon_name}_{time_for_filename}.png"
    plt.savefig(output_filename, dpi=300, bbox_inches='tight')
    print(f"Saved: {output_filename}")

    plt.close(fig)


# ---------- 主循环函数（保留并尽量兼容原代码） ----------
def plot_typeS(start_time_str, end_time_str, inputYear, typhoon_name):
    """
    start_time_str, end_time_str: 'YYYYMMDDHH'
    inputYear: int
    typhoon_name: str
    """
    if not os.path.exists(f"era_plots/{inputYear}_{typhoon_name}/TYPE-SWEAT"):
        os.makedirs(f"era_plots/{inputYear}_{typhoon_name}/TYPE-SWEAT", exist_ok=True)

    CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/nation/省界_Project.shp'
    SOUTH_CHINA_SEA_SHP = 'extraRepo/SHP/china_SHP/southSea/南海诸岛及其它岛屿.shp'
    EAST_ASIA_EXTENT = [70, 140, 15, 55]

    file_path = f'era_data/{inputYear}_{typhoon_name}/ERA5_Global_PL_{inputYear}_{typhoon_name}_00_12Z.nc'
    try:
        ds = xr.open_dataset(file_path)
        # rename if necessary
        if 'valid_time' in ds.coords:
            ds = ds.rename({'valid_time': 'time'})
        # 强制解码时间
        ds = xr.decode_cf(ds)
        print("Data loaded successfully.")
    except FileNotFoundError:
        print(f"Error: File not found at '{file_path}'. Please check the path.")
        return
    except Exception as e:
        print(f"Error opening dataset: {e}")
        return

    # 时间转换
    try:
        start_dt = datetime.strptime(start_time_str, '%Y%m%d%H')
        end_dt = datetime.strptime(end_time_str, '%Y%m%d%H')
    except ValueError as e:
        print(f"Error: Time format must be YYYYMMDDHH. {e}")
        return

    ds_times = ds['time'].to_numpy()
    time_step = timedelta(hours=12)
    current_dt = start_dt

    print(f"Starting plot generation from {start_dt.strftime('%Y%m%d%H')} to {end_dt.strftime('%Y%m%d%H')} (12-hour step).")

    while current_dt <= end_dt:
        try:
            time_index = np.argmin(np.abs(ds_times - np.datetime64(current_dt)))
            data_dt_check = datetime.strptime(ds['time'].isel(time=time_index).dt.strftime('%Y%m%d%H').item(), '%Y%m%d%H')

            if data_dt_check == current_dt:
                _draw_single_plot(ds, time_index, inputYear, typhoon_name)
            else:
                print(f"Skipping time {current_dt.strftime('%Y%m%d%H')}: Exact 12-hourly data point not found.")
        except Exception as e:
            print(f"Error processing time {current_dt.strftime('%Y%m%d%H')}: {e}")

        current_dt += time_step

    print("\n--- All plots generated successfully! ---")


if __name__ == '__main__':
    # 示例运行（替换为你的实际参数）
    plot_typeS('1994081200', '1994082600', 1994, 'Fred')