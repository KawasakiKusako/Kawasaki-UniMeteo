# -*- coding: utf-8 -*-
"""
Final modified script:
- Plots 500 hPa Relative Humidity (R) as filled contours.
- Plots 850 hPa - 500 hPa Wind Shear Magnitude as contour lines (Black, 20m/s highlighted).
- Plots 500 hPa Wind Barbs (Grey).
- Only keeps 1000 hPa Geopotential Height (approximated MSLP) H/L labels and their values.
- Removes all other elements (Z contours, SCS inset, BST track).
"""

import os
import re
from datetime import datetime, timedelta

import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import cartopy.io.shapereader as shpreader
from scipy.ndimage import gaussian_filter, minimum_filter, maximum_filter

# ---------- 用户可修改的路径与参数 ----------
# 假设这些路径可能不存在，如果不存在，绘图会跳过边界绘制，不影响核心功能
CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/nation/省界_Project.shp'
# 南海小窗和BST文件已移除绘图逻辑，但保留路径以防后续需要
# SOUTH_CHINA_SEA_SHP = 'extraRepo/SHP/china_SHP/southSea/南海诸岛及其它岛屿.shp' 
# BST_PATH = 'dataSet/CH1994BST.txt' 
EAST_ASIA_EXTENT = [70, 140, 15, 55]  # [lon_min, lon_max, lat_min, lat_max]
# Map central long for Mercator projection
CENTRAL_LON = 105
# maximum number of H/L labels
MAX_HL_MARKS = 5
# ------------------------------------------------

# ---------- 新增辅助函数：计算相对湿度 ----------
def calculate_relative_humidity(q, T, P_Pa):
    """
    Calculates Relative Humidity (R in %) from Specific Humidity (q, kg/kg), 
    Temperature (T in K), and Pressure (P_Pa in Pascals).
    Uses Bolton (1980) formula for saturation vapor pressure.
    
    Args:
        q (np.ndarray): Specific Humidity (kg/kg).
        T (np.ndarray): Temperature (K).
        P_Pa (float or np.ndarray): Pressure (Pa).
        
    Returns:
        np.ndarray: Relative Humidity (%).
    """
    epsilon = 0.62198 # Ratio of molecular weights of water and dry air
    
    # T must be in Celsius
    Tc = T - 273.15
    
    # 1. Saturation Vapor Pressure (es) in Pa (Bolton, 1980)
    # es = 6.112 * 10^2 * exp( (17.67 * Tc) / (Tc + 243.5) )
    es = 611.2 * np.exp( (17.67 * Tc) / (Tc + 243.5) )
    
    # 2. Vapor Pressure (e) in Pa from Specific Humidity (q) and Total Pressure (P_Pa)
    e = (q * P_Pa) / (epsilon + q * (1 - epsilon))
    
    # 3. Relative Humidity (R) in %
    R = (e / es) * 100
    
    # Clip RH to physical bounds [0, 100]
    R = np.clip(R, 0, 100) 
    
    return R
# ------------------------------------------------


def geopotential_to_mslp_approx(Z1000_vals, C=8.0):
    """
    将 1000 hPa 位势高度 (Z1000) 转换为近似的海平面气压 (MSLP)
    用于 H/L 标注的数值显示。
    """
    if not isinstance(Z1000_vals, np.ndarray):
        Z1000_vals = np.array(Z1000_vals)
        
    mslp_vals = 1000.0 + (Z1000_vals / C)
    
    return mslp_vals

#
def parse_cma_bst(BSTfilepath):
    return [] 

def _draw_single_plot(ds, time_index, inputYear, typhoon_name, bst_tracks=None):
    """
    精简版绘图：
    1. 500hPa 相对湿度（填色图）
    2. 850hPa-500hPa 风切变强度（等值线）
    3. 1000hPa 位势高度 H/L 标记（仅字母和数值）
    4. 500hPa 风羽
    """
    # 切片时间与空间
    data_time = ds['time'].isel(time=time_index)
    data_time_str = data_time.dt.strftime('%Y/%m/%d %HZ').item()

    data_subset = ds.isel(time=time_index).sel(
        latitude=slice(EAST_ASIA_EXTENT[3], EAST_ASIA_EXTENT[2]),
        longitude=slice(EAST_ASIA_EXTENT[0], EAST_ASIA_EXTENT[1])
    )

    try:
        # 1. 1000 hPa 位势高度 (Z1000, 用于 H/L 标记)
        Z1000 = data_subset['z'].sel(pressure_level=1000, method='nearest') / 9.80665 
        
        # 2. 加载 500 hPa Specific Humidity (Q500) 和 Temperature (T500)
        Q500 = data_subset['q'].sel(pressure_level=500, method='nearest') 
        T500 = data_subset['t'].sel(pressure_level=500, method='nearest')
        
        # 3. 850 hPa 和 500 hPa 风场 (用于计算风切变)
        U850 = data_subset['u'].sel(pressure_level=850, method='nearest')
        V850 = data_subset['v'].sel(pressure_level=850, method='nearest')
        U500 = data_subset['u'].sel(pressure_level=500, method='nearest')
        V500 = data_subset['v'].sel(pressure_level=500, method='nearest')
        
    except Exception as e:
        print("数据选择失败：", e)
        return

    # --- 计算 500 hPa 相对湿度 (R500) ---
    # 压力 P 必须是 Pascals (Pa), 500 hPa = 50000 Pa
    P500_Pa = 500 * 100 
    R500_vals = calculate_relative_humidity(Q500.values, T500.values, P500_Pa)
    
    # 将计算结果封装回 xarray DataArray，方便后续使用 .longitude 和 .latitude
    R500 = xr.DataArray(
        R500_vals,
        coords=[Q500.latitude, Q500.longitude],
        dims=['latitude', 'longitude']
    )
    
    # --- 计算 850hPa - 500hPa 风切变强度（标量） ---
    U_shear = U500.values - U850.values
    V_shear = V500.values - V850.values
    # 风切变强度 (Magnitude of Wind Shear, 单位: m/s)
    SHEAR_MAG = np.sqrt(U_shear**2 + V_shear**2) 

    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.Mercator(central_longitude=CENTRAL_LON))
    ax.set_extent(EAST_ASIA_EXTENT, crs=ccrs.PlateCarree())

    try:
        ax.add_feature(cfeature.LAND.with_scale('50m'), facecolor='#F0F0F0')
        ax.add_feature(cfeature.OCEAN.with_scale('50m'), facecolor='white')
        ax.coastlines(resolution='50m', linewidth=0.6, color='k')
    except Exception:
        pass

    if os.path.exists(CHINA_BOUNDARY_SHP):
        try:
            reader = shpreader.Reader(CHINA_BOUNDARY_SHP)
            for geometry in reader.geometries():
                ax.add_geometries([geometry], ccrs.PlateCarree(), facecolor='none', edgecolor='k', linewidth=0.7)
        except Exception as e:
            print("读取边界文件失败：", e)
    else:
        ax.add_feature(cfeature.BORDERS, linestyle=':', alpha=0.7)
#grib
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                      linewidth=0.4, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False
    gl.right_labels = False
    gl.x_inline = False
    gl.xlabel_style = {'size': 9, 'color': 'gray'}
    gl.ylabel_style = {'size': 9, 'color': 'gray'}
#500hPa Rel.hummity
    rh_plot = R500.values 
    vmin = 0; vmax = 100 
    levels_rh = np.linspace(vmin, vmax, 21) 

    cf = ax.contourf(
        R500.longitude, R500.latitude, rh_plot,
        levels=levels_rh,
        cmap='GnBu', alpha=0.5,
        norm=mcolors.BoundaryNorm(levels_rh, ncolors=plt.cm.GnBu.N, clip=False),
        extend='both',
        transform=ccrs.PlateCarree()
    )
    cbar = fig.colorbar(cf, ax=ax, orientation='vertical', pad=0.03, shrink=0.7, alpha=0.5)
    cbar.set_label('500 hPa Relative Humidity (%)')
    
#windshare
    shear_levels = np.arange(5, 30.1, 5) 
    
    # extr 20 m/s）
    shear_levels_thin = shear_levels[shear_levels != 20] 

    cs_shear_thin = ax.contour(
        U850.longitude, U850.latitude, SHEAR_MAG,
        levels=shear_levels_thin,
        colors="#A0A0A0", 
        linewidths=0.7,
        linestyles='--', #虚线
        transform=ccrs.PlateCarree()
    )
    # 20 m/s 
    cs_shear_thick = ax.contour(
        U850.longitude, U850.latitude, SHEAR_MAG,
        levels=[20],
        colors="#252525", 
        linewidths=0.7, 
        linestyles='-', 
        transform=ccrs.PlateCarree()
    )
    ax.clabel(cs_shear_thin, inline=True, fontsize=8, fmt='%d', colors='k')
    ax.clabel(cs_shear_thick, inline=True, fontsize=9, fmt='%d', colors='k')
    # 850wind vect
    skip = 3
    ax.quiver(U850.longitude[::skip], U850.latitude[::skip],
              U850.values[::skip, ::skip], V850.values[::skip, ::skip],
              color='white',
              scale=1000, width=0.0012, headwidth=3.5, headlength=4.5,
              transform=ccrs.PlateCarree())


    Z1000_vals = Z1000.values # geopotential height in meters
    P_mslp_vals = geopotential_to_mslp_approx(Z1000_vals, C=8.0) # 近似MSLP (hPa)

    # H/L 
    smooth_z = gaussian_filter(P_mslp_vals, sigma=2) 
    footprint_size = 15
    maxima = (smooth_z == maximum_filter(smooth_z, size=footprint_size))
    minima = (smooth_z == minimum_filter(smooth_z, size=footprint_size))

    high_thresh = np.percentile(smooth_z[~np.isnan(smooth_z)], 85)
    low_thresh = np.percentile(smooth_z[~np.isnan(smooth_z)], 15)

    H_idx = np.argwhere(maxima & (smooth_z >= high_thresh))
    L_idx = np.argwhere(minima & (smooth_z <= low_thresh))

    # 限制数量
    if H_idx.shape[0] > MAX_HL_MARKS:
        vals = [smooth_z[y, x] for y, x in H_idx]
        order = np.argsort(vals)[-MAX_HL_MARKS:]
        H_idx = H_idx[order]
    if L_idx.shape[0] > MAX_HL_MARKS:
        vals = [smooth_z[y, x] for y, x in L_idx]
        order = np.argsort(vals)[:MAX_HL_MARKS]
        L_idx = L_idx[order]

    # 绘制 H / L（上：字母；下：近似 MSLP 值 hPa）
    for y, x in H_idx:
        lon0 = Z1000.longitude.values[x]
        lat0 = Z1000.latitude.values[y]
        center_p = float(P_mslp_vals[y, x]) 
        p_txt = f"{int(round(center_p))}"

        ax.text(lon0, lat0 + 0.35, 'H', color='blue', fontsize=14, fontweight='bold',
                 ha='center', va='center', transform=ccrs.PlateCarree())
        ax.text(lon0, lat0 - 0.7, p_txt, color='blue', fontsize=10, fontweight='bold',
                 ha='center', va='center', transform=ccrs.PlateCarree())

    for y, x in L_idx:
        lon0 = Z1000.longitude.values[x]
        lat0 = Z1000.latitude.values[y]
        center_p = float(P_mslp_vals[y, x]) 
        p_txt = f"{int(round(center_p))}"

        ax.text(lon0, lat0 + 0.35, 'L', color='red', fontsize=14, fontweight='bold',
                 ha='center', va='center', transform=ccrs.PlateCarree())
        ax.text(lon0, lat0 - 0.7, p_txt, color='red', fontsize=10, fontweight='bold',
                 ha='center', va='center', transform=ccrs.PlateCarree())


    # ----- 标题与注释（精简版） -----
    ax.set_title(
        f"500hPa RH (Filled) + 850-500hPa Wind Shear (Contour) + 500hPa Wind (Barb) + MSLP H/L", 
        loc='left', 
        fontsize=11, 
        color='black',
        pad=20 
    )

    ax.text(
        x=0.00, 
        y=1.03,
        s=f"Data valid at {data_time_str}  Source: ERA5  CDUT CMS @ KawasakiKusako",
        transform=ax.transAxes,
        horizontalalignment='left',
        fontsize=9, 
        color='dimgray',
        verticalalignment='top'
    )

    # ----- 保存图像 -----
    out_dir = f"era_plots/{inputYear}_{typhoon_name}/TYPE-C"
    if not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    time_for_filename = data_time.dt.strftime('%Y%m%d%H').item()
    output_filename = f"{out_dir}/TYPE-C-{inputYear}_{typhoon_name}_{time_for_filename}.png" 
    plt.savefig(output_filename, dpi=300, bbox_inches='tight')
    print("Saved:", output_filename)
    plt.close(fig)


def plot_typeC(start_time_str, end_time_str, inputYear, typhoon_name):
    
    if not os.path.exists(f"era_plots/{inputYear}_{typhoon_name}/TYPE-C"):
        os.makedirs(f"era_plots/{inputYear}_{typhoon_name}/TYPE-C")
    
    """
    主函数：读取 ERA5 netCDF, 遍历 12 小时步长并调用绘图。
    start_time_str, end_time_str 格式： 'YYYYMMDDHH'
    """
    file_path = f'era_data/{inputYear}_{typhoon_name}/ERA5_Global_PL_{inputYear}_{typhoon_name}_00_12Z.nc'
    try:
        # 使用 decode_coords=False 提高兼容性
        ds = xr.open_dataset(file_path, decode_coords=False) 
        if 'valid_time' in ds.coords and 'time' not in ds.coords:
            ds = ds.rename({'valid_time': 'time'})
        try:
            # 重新编码时间坐标
            ds['time'] = xr.decode_cf(ds).time 
        except Exception:
            pass
        print("Data loaded.")
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return

    # 移除 BST 轨迹读取
    bst_tracks = [] # parse_cma_bst(BST_PATH) 

    # 时间解析
    try:
        start_dt = datetime.strptime(start_time_str, '%Y%m%d%H')
        end_dt = datetime.strptime(end_time_str, '%Y%m%d%H')
    except Exception as e:
        print("时间字符串格式错误，应为 YYYYMMDDHH:", e)
        return

    ds_times = ds['time'].to_numpy()
    time_step = timedelta(hours=12)
    current_dt = start_dt

    print(f"Generating from {start_dt} to {end_dt} ...")
    while current_dt <= end_dt:
        try:
            idx = int(np.argmin(np.abs(ds_times - np.datetime64(current_dt))))
            _draw_single_plot(ds, idx, inputYear, typhoon_name, bst_tracks=bst_tracks)
        except Exception as e:
            print("Error for time", current_dt, e)
        current_dt += time_step

    print("All done.")


if __name__ == '__main__':
    # 示例调用（请根据实际数据时间/路径修改）
    plot_typeC('1994081218', '1994082600', 1994, 'Fred')
