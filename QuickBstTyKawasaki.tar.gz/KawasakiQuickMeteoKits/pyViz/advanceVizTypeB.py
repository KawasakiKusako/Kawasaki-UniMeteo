# -*- coding: utf-8 -*-
"""
Final integrated script:
- Uses 1000 hPa geopotential height (m) for contours and H/L detection (no MSLP conversion).
- Plots 850 hPa vorticity (filled), 850 hPa wind barbs (masked for near-zero wind).
- Reads optional CMA BST typhoon file (dataSet/BST.txt) to mark TC position.
- Keeps layout similar to original: main map + South China Sea inset, title, colorbar, output file.
"""

import os
import re
from datetime import datetime, timedelta

import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import cartopy.io.shapereader as shpreader
from scipy.ndimage import gaussian_filter, minimum_filter, maximum_filter

# ---------- 用户可修改的路径与参数 ----------
CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/nation/省界_Project.shp'
SOUTH_CHINA_SEA_SHP = 'extraRepo/SHP/china_SHP/southSea/南海诸岛及其它岛屿.shp'
BST_PATH = 'dataSet/CH1994BST.txt'   # CMA 台风最佳路径文件（用户提供）
EAST_ASIA_EXTENT = [70, 140, 15, 55]  # [lon_min, lon_max, lat_min, lat_max]
# Map central long for Mercator projection
CENTRAL_LON = 105
# Wind barb mask threshold (m/s): points with windspeed <= this will not be plotted
WIND_MASK_THRESHOLD = 2.5
# maximum number of H/L labels
MAX_HL_MARKS = 5
# ------------------------------------------------


def geopotential_to_mslp_approx(Z1000_vals, C=8.0):
    """
    将 1000 hPa 位势高度 (Z1000) 转换为近似的海平面气压 (MSLP)
    
    这个转换基于一个常用的线性近似: 
    MSLP (hPa) = 1000 + Z1000 (m) / C
    其中 C 是一个经验常数, 范围通常在 8 到 10 之间。
    
    参数:
    ----------
    Z1000_vals : numpy.ndarray 或 float
        1000 hPa 位势高度的值 (单位: 米)。
    C : float, 可选
        线性近似的经验系数 (单位: 米/hPa)。
        默认值 C=8.0 (即每 8 米高度差对应 1 hPa 气压差)。
        
    返回:
    ----------
    numpy.ndarray 或 float
        近似的海平面气压值 (单位: hPa)。
    """
    
    # 确保输入是 numpy 数组，方便处理
    if not isinstance(Z1000_vals, np.ndarray):
        Z1000_vals = np.array(Z1000_vals)
        
    # 应用公式: MSLP = 1000 + Z1000 / C
    mslp_vals = 1000.0 + (Z1000_vals / C)
    
    return mslp_vals

# --- 示例用法 ---
# 假设你的 Z1000 位势高度数据如下 (例如: 80 米, 48 米, 120 米)
Z1000_data = np.array([80.0, 48.0, 120.0, 16.0])

# 使用默认系数 C=8.0 进行转换
P_mslp_8 = geopotential_to_mslp_approx(Z1000_data, C=8.0)
print(f"Z1000 (m): {Z1000_data}")
print(f"近似海平面气压 (C=8.0, hPa): {P_mslp_8}") 
# 结果: [1010.0, 1006.0, 1015.0, 1002.0]

# 使用另一个系数 C=9.8 进行转换
P_mslp_98 = geopotential_to_mslp_approx(Z1000_data, C=9.8)
print(f"近似海平面气压 (C=9.8, hPa): {P_mslp_98.round(2)}")
# 结果: [1008.16, 1004.90, 1012.24, 1001.63]

def parse_cma_bst(BSTfilepath):
    """
    解析 CMA BST 台风文件（尽量兼容常见格式）。
    返回 list of dict { 'time': datetime, 'lat': float, 'lon': float, 'name': str or None }
    """
    if not os.path.exists(BSTfilepath):
        return []

    tracks = []
    with open(BSTfilepath, 'r', encoding='utf-8', errors='ignore') as f:
        text = f.read()

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue

        time_match = re.search(r'(\d{4}\s*\d{2}\s*\d{2}\s*\d{2})', line) or \
                     re.search(r'(\d{8}\d{2})', line) or \
                     re.search(r'(\d{4}-\d{2}-\d{2}\s*\d{2})', line)

        lat = None
        lon = None
        name = None

        lat_match = re.search(r'([0-9]{1,2}\.\d+)\s*([NS])', line, re.I) or \
                    re.search(r'([+-]?\d{1,2}\.\d+)\s*(deg)?\s*[, ]', line)
        lon_match = re.search(r'([0-9]{2,3}\.\d+)\s*([EW])', line, re.I) or \
                    re.search(r'([+-]?\d{2,3}\.\d+)\s*(deg)?\s*[, ]', line)

        if lat_match and lon_match:
            try:
                lat_val = float(lat_match.group(1))
                if lat_match.groups()[-1] and lat_match.groups()[-1].upper() == 'S':
                    lat_val = -lat_val
                lat = lat_val
            except Exception:
                lat = None
            try:
                lon_val = float(lon_match.group(1))
                if lon_match.groups()[-1] and lon_match.groups()[-1].upper() == 'W':
                    lon_val = -lon_val
                lon = lon_val
            except Exception:
                lon = None
        else:
            floats = re.findall(r'([+-]?\d+\.\d+)', line)
            if len(floats) >= 2:
                a = float(floats[0]); b = float(floats[1])
                if 0 <= a <= 180 and -90 <= b <= 90:
                    lon, lat = a, b
                elif 0 <= b <= 180 and -90 <= a <= 90:
                    lon, lat = b, a
                else:
                    lon, lat = floats[0], floats[1]

        if time_match:
            tstr = time_match.group(1)
            tstr = re.sub(r'\s+', '', tstr)
            try:
                if len(tstr) == 10:
                    t = datetime.strptime(tstr, '%Y%m%d%H')
                elif '-' in tstr:
                    t = datetime.strptime(tstr, '%Y-%m-%d%H')
                else:
                    t = datetime.strptime(tstr, '%Y%m%d%H')
            except Exception:
                try:
                    parts = re.findall(r'\d+', time_match.group(1))
                    if len(parts) >= 4:
                        y, mo, d, hh = parts[:4]
                        t = datetime(int(y), int(mo), int(d), int(hh))
                    else:
                        continue
                except Exception:
                    continue
        else:
            continue

        if lat is None or lon is None:
            continue

        tracks.append({'time': t, 'lat': float(lat), 'lon': float(lon), 'name': name})

    tracks.sort(key=lambda x: x['time'])
    return tracks


def _draw_single_plot(ds, time_index, inputYear, typhoon_name, bst_tracks=None):
    """
    绘制单一时刻图像：
    - 使用 1000hPa 位势高度 Z1000 (m) 绘制等高线并标 H/L（位势高度中心）
    - 绘制 850hPa 涡度（filled）与 850hPa 风羽（barbs，屏蔽弱风）
    - 标注台风点（若有）
    """
    # 切片时间与空间
    data_time = ds['time'].isel(time=time_index)
    data_time_str = data_time.dt.strftime('%Y/%m/%d %HZ').item()

    data_subset = ds.isel(time=time_index).sel(
        latitude=slice(EAST_ASIA_EXTENT[3], EAST_ASIA_EXTENT[2]),
        longitude=slice(EAST_ASIA_EXTENT[0], EAST_ASIA_EXTENT[1])
    )

    try:
        # 保留读取 Z500（即使不画）以兼容原结构
        Z500 = data_subset['z'].sel(pressure_level=500, method='nearest') / 9.80665
        Z1000 = data_subset['z'].sel(pressure_level=1000, method='nearest') / 9.80665
        U850 = data_subset['u'].sel(pressure_level=850, method='nearest')
        V850 = data_subset['v'].sel(pressure_level=850, method='nearest')
    except Exception as e:
        print("数据选择失败：", e)
        return

    # --- 计算 850hPa 相对涡度（近似） ---
    lons = U850.longitude.values
    lats = U850.latitude.values
    uu = U850.values
    vv = V850.values

    # 网格间距简化估算（米）
    lat_rad = np.deg2rad(lats)
    dx = 111000.0 * np.cos(lat_rad)
    dy = 111000.0

    # 计算涡度（近似）
    try:
        dudy = np.gradient(uu, dy, axis=0)
        dvdx = np.gradient(vv, dx, axis=1)
        VORT850 = dvdx - dudy
    except Exception:
        # 备用 finite difference
        dudy = np.empty_like(uu); dvdx = np.empty_like(vv)
        dudy[1:-1, :] = (uu[2:, :] - uu[:-2, :]) / (2 * dy)
        dudy[0, :] = (uu[1, :] - uu[0, :]) / dy
        dudy[-1, :] = (uu[-1, :] - uu[-2, :]) / dy
        dx2d = np.tile(dx[:, None], (1, uu.shape[1]))
        dvdx[:, 1:-1] = (vv[:, 2:] - vv[:, :-2]) / (2 * dx2d[:, 1:-1])
        dvdx[:, 0] = (vv[:, 1] - vv[:, 0]) / dx2d[:, 0]
        dvdx[:, -1] = (vv[:, -1] - vv[:, -2]) / dx2d[:, -1]
        VORT850 = dvdx - dudy

    # ----- 绘图主体 -----
    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.Mercator(central_longitude=CENTRAL_LON))
    ax.set_extent(EAST_ASIA_EXTENT, crs=ccrs.PlateCarree())

    try:
        ax.add_feature(cfeature.LAND.with_scale('50m'), facecolor='#F0F0F0')
        ax.add_feature(cfeature.OCEAN.with_scale('50m'), facecolor='white')
        ax.coastlines(resolution='50m', linewidth=0.6, color='k')
    except Exception:
        pass

    # 中国边界（若存在 shapefile）
    if os.path.exists(CHINA_BOUNDARY_SHP):
        try:
            reader = shpreader.Reader(CHINA_BOUNDARY_SHP)
            for geometry in reader.geometries():
                ax.add_geometries([geometry], ccrs.PlateCarree(), facecolor='none', edgecolor='k', linewidth=0.7)
        except Exception as e:
            print("读取边界文件失败：", e)
    else:
        ax.add_feature(cfeature.BORDERS, linestyle=':', alpha=0.7)

    # 网格线
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                      linewidth=0.4, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False
    gl.right_labels = False
    gl.x_inline = False
    gl.xlabel_style = {'size': 9, 'color': 'gray'}
    gl.ylabel_style = {'size': 9, 'color': 'gray'}

    # ----- 850hPa 涡度（纯色填色） -----
    vort_plot = VORT850 * 1e5
    vmin = -20; vmax = 20
    levels_vort = np.linspace(vmin, vmax, 41)
    cf = ax.contourf(
        lons, lats, vort_plot,
        levels=levels_vort,
        cmap='RdBu_r',
        norm=mcolors.BoundaryNorm(levels_vort, ncolors=plt.cm.RdBu_r.N, clip=False),
        extend='both',
        transform=ccrs.PlateCarree()
    )
    cbar = fig.colorbar(cf, ax=ax, orientation='vertical', pad=0.03, shrink=0.7)
    cbar.set_label('850 hPa Vorticity ($10^{-5}\\,$s$^{-1}$)')

    # ----- 850hPa 风羽（barbs），过滤弱风点 -----
    skip = 7
    U_grid = U850.values[::skip, ::skip]
    V_grid = V850.values[::skip, ::skip]
    wind_speed = np.sqrt(U_grid**2 + V_grid**2)
    mask = wind_speed > WIND_MASK_THRESHOLD

    lon = U850.longitude.values[::skip]
    lat = U850.latitude.values[::skip]
    Lon, Lat = np.meshgrid(lon, lat)

    if np.any(mask):
        ax.barbs(
            Lon[mask], Lat[mask],
            U_grid[mask], V_grid[mask],
            length=6,
            linewidth=0.6,
            barbcolor='black',
            flagcolor='black',
            transform=ccrs.PlateCarree()
        )

    # ----- 使用 1000hPa 位势高度 (m) 绘制等高线（不做气压转换） -----
    Z1000_vals = Z1000.values  # geopotential height in meters

    Z1000_vals = Z1000.values # geopotential height in meters
    P_mslp_vals = geopotential_to_mslp_approx(Z1000_vals, C=8.0)

    Z1000_vals = P_mslp_vals


    # 自动选择步长以保证图面清爽
    min_z = np.nanmin(Z1000_vals)
    max_z = np.nanmax(Z1000_vals)
    z_range = max_z - min_z
    if z_range > 200:
        step_z = 10
    elif z_range > 80:
        step_z = 5
    else:
        step_z = 2

    levels_z = np.arange(np.floor(min_z / step_z) * step_z,
                         np.ceil(max_z / step_z) * step_z + 1, step_z)

    cs_z = ax.contour(
        Z1000.longitude, Z1000.latitude, Z1000_vals,
        levels=levels_z,
        colors="#9B9B9B",
        linewidths=0.5,
        linestyles='-',
        transform=ccrs.PlateCarree()
    )
    ax.clabel(cs_z, inline=True, fontsize=7, fmt='%d')

    # ----- 标注主要高/低位势中心（基于 Z1000，避免把 TC 误判为高压） -----
    smooth_z = gaussian_filter(Z1000_vals, sigma=2)
    footprint_size = 15
    maxima = (smooth_z == maximum_filter(smooth_z, size=footprint_size))
    minima = (smooth_z == minimum_filter(smooth_z, size=footprint_size))

    high_thresh = np.percentile(smooth_z[~np.isnan(smooth_z)], 85)
    low_thresh = np.percentile(smooth_z[~np.isnan(smooth_z)], 15)

    H_idx = np.argwhere(maxima & (smooth_z >= high_thresh))
    L_idx = np.argwhere(minima & (smooth_z <= low_thresh))

    # 限制数量
    if H_idx.shape[0] > MAX_HL_MARKS:
        vals = [smooth_z[y, x] for y, x in H_idx]
        order = np.argsort(vals)[-MAX_HL_MARKS:]
        H_idx = H_idx[order]
    if L_idx.shape[0] > MAX_HL_MARKS:
        vals = [smooth_z[y, x] for y, x in L_idx]
        order = np.argsort(vals)[:MAX_HL_MARKS]
        L_idx = L_idx[order]

    # 绘制 H / L（上：字母；下：位势高度 m）
    for y, x in H_idx:
        lon0 = Z1000.longitude.values[x]
        lat0 = Z1000.latitude.values[y]
        center_z = float(Z1000_vals[y, x])
        z_txt = f"{int(round(center_z))}"

        ax.text(lon0, lat0 + 0.35, 'H', color='blue', fontsize=14, fontweight='bold',
                ha='center', va='center', transform=ccrs.PlateCarree())
        ax.text(lon0, lat0 - 0.7, z_txt, color='blue', fontsize=10, fontweight='bold',
                ha='center', va='center', transform=ccrs.PlateCarree())

    for y, x in L_idx:
        lon0 = Z1000.longitude.values[x]
        lat0 = Z1000.latitude.values[y]
        center_z = float(Z1000_vals[y, x])
        z_txt = f"{int(round(center_z))}"

        ax.text(lon0, lat0 + 0.35, 'L', color='red', fontsize=14, fontweight='bold',
                ha='center', va='center', transform=ccrs.PlateCarree())
        ax.text(lon0, lat0 - 0.7, z_txt, color='red', fontsize=10, fontweight='bold',
                ha='center', va='center', transform=ccrs.PlateCarree())

    # ----- 南海小窗口（保持原来布局） -----
    draw_scs_features = os.path.exists(SOUTH_CHINA_SEA_SHP)
    ax_scs = fig.add_axes([0.13, 0.2, 0.09, 0.18], projection=ccrs.PlateCarree())
    ax_scs.set_extent([105, 122, 0, 25], crs=ccrs.PlateCarree())
    ax_scs.axis('off')
    ax_scs.set_frame_on(True)
    ax_scs.patch.set_edgecolor('black')
    ax_scs.patch.set_linewidth(1.2)
    try:
        ax_scs.add_feature(cfeature.LAND, facecolor='lightgray')
        ax_scs.add_feature(cfeature.OCEAN, facecolor='white')
        ax_scs.coastlines(resolution='50m', linewidth=0.5)
    except Exception:
        pass
    if draw_scs_features:
        try:
            reader = shpreader.Reader(SOUTH_CHINA_SEA_SHP)
            for geometry in reader.geometries():
                ax_scs.add_geometries([geometry], ccrs.PlateCarree(), facecolor='none', edgecolor='k', linewidth=0.5)
        except Exception:
            pass

    # ----- 标题与注释 -----
    # --- 标题 (左上角) ---
    
    # 1. 绘制主标题 (Title)
    ax.set_title(
        f"ERA-5 MSLP (extrama) & 850hPa Vorticity + 850hPa Wind barbs",
        loc='left', 
        fontsize=11, 
        color='black',
        pad=20 
    )

    # 2. 绘制副标题 (Subtitle)
    ax.text(
        x=0.00, 
        y=1.03,
        s=f"Historical Data : {data_time_str} valid at {data_time_str}  CDUT CMS @Kawasaki Kusako ",
        transform=ax.transAxes,
        # 修正：将 loc='left' 替换为 horizontalalignment='left'
        horizontalalignment='left', # 或 ha='left'
        fontsize=9, 
        color='dimgray',
        verticalalignment='top'
    )

    # ----- 台风轨迹标注（若有） -----
    if bst_tracks and len(bst_tracks) > 0:
        cur_time = data_time.dt.to_pydatetime().item()
        diffs = [abs((pt['time'] - cur_time).total_seconds()) for pt in bst_tracks]
        idx = int(np.argmin(diffs))
        tc = bst_tracks[idx]
        if (EAST_ASIA_EXTENT[0] <= tc['lon'] <= EAST_ASIA_EXTENT[1]) and (EAST_ASIA_EXTENT[2] <= tc['lat'] <= EAST_ASIA_EXTENT[3]):
            ax.plot(tc['lon'], tc['lat'], 'o', color='magenta', markersize=8, transform=ccrs.PlateCarree(), zorder=10)
            label = typhoon_name if typhoon_name else 'TC'
            ax.text(tc['lon'] + 0.4, tc['lat'] + 0.4, label, color='magenta', fontsize=10, transform=ccrs.PlateCarree())

    # ----- 保存图像 -----
    out_dir = f"era_plots/{inputYear}_{typhoon_name}/TYPE-B"
    if not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    time_for_filename = data_time.dt.strftime('%Y%m%d%H').item()
    output_filename = f"{out_dir}/TYPE-B-{inputYear}_{typhoon_name}_{time_for_filename}.png"
    plt.savefig(output_filename, dpi=300, bbox_inches='tight')
    print("Saved:", output_filename)
    plt.close(fig)


def plot_typeB(start_time_str, end_time_str, inputYear, typhoon_name):

    if not os.path.exists(f"era_plots/{inputYear}_{typhoon_name}/TYPE-B"):
        os.makedirs(f"era_plots/{inputYear}_{typhoon_name}/TYPE-B")
    """
    主函数：读取 ERA5 netCDF, 遍历 12 小时步长并调用绘图。
    start_time_str, end_time_str 格式： 'YYYYMMDDHH'
    """
    file_path = f'era_data/{inputYear}_{typhoon_name}/ERA5_Global_PL_{inputYear}_{typhoon_name}_00_12Z.nc'
    try:
        ds = xr.open_dataset(file_path)
        if 'valid_time' in ds.coords and 'time' not in ds.coords:
            ds = ds.rename({'valid_time': 'time'})
        try:
            ds['time'] = xr.decode_cf(ds).time
        except Exception:
            pass
        print("Data loaded.")
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return

    # 读取台风轨迹（若有）
    bst_tracks = parse_cma_bst(BST_PATH)

    # 时间解析
    try:
        start_dt = datetime.strptime(start_time_str, '%Y%m%d%H')
        end_dt = datetime.strptime(end_time_str, '%Y%m%d%H')
    except Exception as e:
        print("时间字符串格式错误，应为 YYYYMMDDHH:", e)
        return

    ds_times = ds['time'].to_numpy()
    time_step = timedelta(hours=12)
    current_dt = start_dt

    print(f"Generating from {start_dt} to {end_dt} ...")
    while current_dt <= end_dt:
        try:
            idx = int(np.argmin(np.abs(ds_times - np.datetime64(current_dt))))
            _draw_single_plot(ds, idx, inputYear, typhoon_name, bst_tracks=bst_tracks)
        except Exception as e:
            print("Error for time", current_dt, e)
        current_dt += time_step

    print("All done.")

if __name__ == '__main__':
    # 示例调用（请根据实际数据时间/路径修改）
    plot_typeB('1994081218', '1994082600', 1994, 'Fred')
