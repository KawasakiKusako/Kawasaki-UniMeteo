
# --- ERA-5 850hPa Temperature (°C), Wind & 500hPa Geopotential Height ---

def _draw_single_plot(ds, time_index, inputYear, typhoon_name):

    import xarray as xr
    import matplotlib.pyplot as plt
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
    import cartopy.io.shapereader as shpreader
    import numpy as np
    import os
    import matplotlib.colors as mcolors
    from datetime import datetime, timedelta

    
    CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/nation/省界_Project.shp'
    SOUTH_CHINA_SEA_SHP = 'extraRepo/SHP/china_SHP/southSea/南海诸岛及其它岛屿.shp'
    EAST_ASIA_EXTENT = [70, 140, 15, 55] # [lon_min, lon_max, lat_min, lat_max]

    data_time_str = ds['time'].isel(time=time_index).dt.strftime('%Y/%m/%d %HZ').item()
    
    data_subset = ds.isel(time=time_index).sel(
        latitude=slice(EAST_ASIA_EXTENT[3], EAST_ASIA_EXTENT[2]), # !!纬度是倒序切片
        longitude=slice(EAST_ASIA_EXTENT[0], EAST_ASIA_EXTENT[1])
    )
    '''
    try:
        Z500 = data_subset['z'].sel(pressure_level=500, method='nearest') / 9.80665
        T850 = data_subset['t'].sel(pressure_level=850, method='nearest') - 273.15
        U850 = data_subset['u'].sel(pressure_level=850, method='nearest')
        V850 = data_subset['v'].sel(pressure_level=850, method='nearest')
    except KeyError as e:
        print(f"Error: Variable or pressure level selection failed: {e}")
        return
    '''
    try:
        Z500 = data_subset['z'].sel(pressure_level=100, method='nearest') / 9.80665
        T850 = data_subset['t'].sel(pressure_level=100, method='nearest') - 273.15
        U850 = data_subset['u'].sel(pressure_level=100, method='nearest')
        V850 = data_subset['v'].sel(pressure_level=100, method='nearest')
    except KeyError as e:
        print(f"Error: Variable or pressure level selection failed: {e}")
        return
    # plot
    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.Mercator(central_longitude=105))

    ax.set_extent(EAST_ASIA_EXTENT, crs=ccrs.PlateCarree())

    # map + coastline （cartopy failed allow pass）
    try:
        ax.add_feature(cfeature.LAND, facecolor="#000000CB")
        ax.coastlines(resolution='50m', linewidth=0.8, color='k')
    except Exception:
        pass 

    # map + china boundary
    if os.path.exists(CHINA_BOUNDARY_SHP):
        try:
            reader = shpreader.Reader(CHINA_BOUNDARY_SHP)
            for geometry in reader.geometries():
                ax.add_geometries([geometry], ccrs.PlateCarree(),
                                facecolor='none', edgecolor='k', linewidth=1.0)
        except Exception as e:
            print(f"!!! 警告: 读取国标 Shapefile 失败: {e}")
    else:
        ax.add_feature(cfeature.BORDERS, linestyle=':', alpha=0.8, edgecolor='k')


    
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                      linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False #gird
    gl.right_labels = False
    gl.x_inline = False
    gl.xlabel_style = {'size': 10, 'color': 'gray'}
    gl.ylabel_style = {'size': 10, 'color': 'gray'}

    colors = [
        "#FFE1F2", "#F030EA", '#C03090', '#9030C0', '#6030F0', '#3060F0',
        '#3090F0', '#30C0C0', '#60F090', '#C0F030', '#FFD030', '#FF9030',
        '#FF3040', '#FF6080', '#FFA0C0', "#FFE0F0" 
    ]
    
    # pinghua
    SMOOTH_N = 256 
    custom_cmap = mcolors.LinearSegmentedColormap.from_list('custom_thermometer', colors, N=SMOOTH_N)
    temp_ticks = np.arange(-100, -7, 3) # -45, -42, ..., 45

    # 我们使用更密集的级别（例如 1°C 间隔），以创建视觉上的渐变效果。
    dense_levels = np.arange(temp_ticks.min(), temp_ticks.max() + 1, 1)
    # 这确保了颜色映射的整个范围（0到1）被充分使用
    norm = mcolors.BoundaryNorm(dense_levels, ncolors=custom_cmap.N, clip=False)

    cf = ax.contourf(T850.longitude, T850.latitude, T850,
                     levels=dense_levels,  # 使用密集的级别进行填色
                     cmap=custom_cmap, 
                     norm=norm,           # 使用 BoundaryNorm 来控制颜色和级别的对应
                     extend='both',
                     transform=ccrs.PlateCarree())

    # 颜色条使用我们最初的刻度
    cbar = fig.colorbar(cf, ax=ax, orientation='vertical', pad=0.03, shrink=0.7, 
                        label='Temperature ($\mathrm{^\circ C}$)')
    # 使用 temp_ticks 设置颜色条的标签位置
    cbar.set_ticks(temp_ticks)
    
    temp_contour_levels = np.arange(-110, 10, 10)
    cs_temp_light = ax.contour(T850.longitude, T850.latitude, T850,
                              levels=temp_contour_levels, colors='silver', linewidths=0.5, linestyles='-',
                              transform=ccrs.PlateCarree())
    ax.clabel(cs_temp_light, inline=True, fontsize=7, fmt='%.0f', colors='silver')

    cs0c = ax.contour(T850.longitude, T850.latitude, T850,
                      levels=[-50], colors='white', linewidths=2.0, linestyles='-',
                      transform=ccrs.PlateCarree())
    ax.clabel(cs0c, inline=True, fontsize=10, fmt='0$\mathrm{^\circ C}$', colors='white')


    #500 hPa GPT
    levels_500 = np.arange(15000, 20000, 100)
    cs500 = ax.contour(Z500.longitude, Z500.latitude, Z500,
                       levels=levels_500, colors='k', linewidths=0.8,
                       transform=ccrs.PlateCarree())
    ax.clabel(cs500, inline=True, fontsize=8, fmt='%d', colors='k')

    if 16600 in levels_500:
        cs16600 = ax.contour(Z500.longitude, Z500.latitude, Z500,
                            levels=[16600], colors='r', linewidths=2.5,
                            transform=ccrs.PlateCarree())
        ax.clabel(cs16600, inline=True, fontsize=10, fmt='16600', colors='r')


    #850 hPa WIND
    skip = 5
    ax.quiver(U850.longitude[::skip], U850.latitude[::skip],
              U850.values[::skip, ::skip], V850.values[::skip, ::skip],
              color='white',
              scale=1000, width=0.0012, headwidth=3.5, headlength=4.5,
              transform=ccrs.PlateCarree())


#南海
    draw_scs_features = os.path.exists(SOUTH_CHINA_SEA_SHP)
    ax_scs = fig.add_axes([0.13, 0.2, 0.09, 0.18], projection=ccrs.PlateCarree())
    ax_scs.set_extent([105, 122, 0, 25], crs=ccrs.PlateCarree())
    ax_scs.axis('off')
    ax_scs.set_frame_on(True)
    ax_scs.patch.set_edgecolor('black')
    ax_scs.patch.set_linewidth(1.5)
    ax_scs.add_feature(cfeature.LAND, facecolor='lightgray')
    ax_scs.add_feature(cfeature.OCEAN, facecolor='white')
    ax_scs.coastlines(resolution='50m', linewidth=0.5, color='k')
        
    if draw_scs_features:
        try:
            reader = shpreader.Reader(SOUTH_CHINA_SEA_SHP)
            for geometry in reader.geometries():
                ax_scs.add_geometries([geometry], ccrs.PlateCarree(),
                                      facecolor='none', edgecolor='k', linewidth=0.5)
        except Exception:
            pass


# --- 标题 (左上角) ---
    
    # 1. 绘制主标题 (Title)
    ax.set_title(
        f"ERA-5 100hPa Temperature (°C), Wind & Geopotential Height",
        loc='left', # <--- ax.set_title 支持 loc
        fontsize=11, 
        color='black',
        pad=20 
    )

    # 2. 绘制副标题 (Subtitle)
    ax.text(
        x=0.00, 
        y=1.03,
        s=f"Historical Data : {data_time_str} valid at {data_time_str}  CDUT CMS @Kawasaki Kusako ",
        transform=ax.transAxes,
        # 修正：将 loc='left' 替换为 horizontalalignment='left'
        horizontalalignment='left', # 或 ha='left'
        fontsize=9, 
        color='dimgray',
        verticalalignment='top'
    )
    # --- 保存文件 (关键步骤: 文件名包含时间) ---
    # 使用 YYYYMMDDHH 格式命名文件
    if not os.path.exists(f"era_plots/{inputYear}_{typhoon_name}/TYPE-A-100hPa"):
        os.mkdir(f"era_plots/{inputYear}_{typhoon_name}/TYPE-A-100hPa")

    time_for_filename = ds['time'].isel(time=time_index).dt.strftime('%Y%m%d%H').item()
    
    output_filename = f"era_plots/{inputYear}_{typhoon_name}/TYPE-A-100hPa/TYPE-A-100hPa-{inputYear}_{typhoon_name}_{time_for_filename}.png"
    plt.savefig(output_filename, dpi=300, bbox_inches='tight')
    print(f"Saved: {output_filename}")
    
    # 必须关闭图形，释放内存
    plt.close(fig)


def plot_typeA100(start_time_str, end_time_str, inputYear, typhoon_name):
    import xarray as xr
    import matplotlib.pyplot as plt
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
    import cartopy.io.shapereader as shpreader
    import numpy as np
    import os
    import matplotlib.colors as mcolors
    from datetime import datetime, timedelta

    if not os.path.exists(f"era_plots/{inputYear}_{typhoon_name}/TYPE-A-100hPa"):
        os.makedirs(f"era_plots/{inputYear}_{typhoon_name}/TYPE-A-100hPa")
    
    CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/nation/省界_Project.shp'
    SOUTH_CHINA_SEA_SHP = 'extraRepo/SHP/china_SHP/southSea/南海诸岛及其它岛屿.shp'
    EAST_ASIA_EXTENT = [70, 140, 15, 55] # 绘图范围 [lon_min, lon_max, lat_min, lat_max]

    # --- 1. 加载数据 ---
    file_path = f'era_data/{inputYear}_{typhoon_name}/ERA5_Global_PL_{inputYear}_{typhoon_name}_00_12Z.nc'
    try:
        ds = xr.open_dataset(file_path)
        ds = ds.rename({'valid_time': 'time'})
        # 强制将时间变量解码为 datetime 对象
        if 'time' in ds.coords:
            ds['time'] = xr.decode_cf(ds).time
        print("Data loaded successfully.")
    except FileNotFoundError:
        print(f"Error: File not found at '{file_path}'. Please check the path.")
        return

    # --- 2. 转换起始/结束时间为 datetime 对象 ---
    try:
        start_dt = datetime.strptime(start_time_str, '%Y%m%d%H')
        end_dt = datetime.strptime(end_time_str, '%Y%m%d%H')
    except ValueError as e:
        print(f"Error: Time format must be YYYYMMDDHH (e.g., 1994051018). Original error: {e}")
        return

    # --- 3. 开始循环 ---
    ds_times = ds['time'].to_numpy()
    time_step = timedelta(hours=12)
    current_dt = start_dt

    print(f"Starting plot generation from {start_dt.strftime('%Y%m%d%H')} to {end_dt.strftime('%Y%m%d%H')} (12-hour step).")

    while current_dt <= end_dt:
        try:
            # 找到最接近当前时间 current_dt 的 time 索引
            # np.datetime64(current_dt) 用于与 xarray 的时间数组进行比较
            time_index = np.argmin(np.abs(ds_times - np.datetime64(current_dt)))
            
            # 检查找到的索引对应的时间是否精确匹配
            data_dt_check = datetime.strptime(ds['time'].isel(time=time_index).dt.strftime('%Y%m%d%H').item(), '%Y%m%d%H')
            
            if data_dt_check == current_dt:
                _draw_single_plot(ds, time_index, inputYear, typhoon_name)
            else:
                 print(f"Skipping time {current_dt.strftime('%Y%m%d%H')}: Exact 6-hourly data point not found.")
                 
        except Exception as e:
            print(f"Error processing time {current_dt.strftime('%Y%m%d%H')}: {e}")
            
        # 移动到下一个 6 小时
        current_dt += time_step
        
    print("\n--- All plots generated successfully! ---")


if __name__ == '__main__':
    # 替换为您的实际输入参数
    plot_typeA100('1994081218', '1994082600', 1994, 'Fred')