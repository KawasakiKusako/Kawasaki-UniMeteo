import os
import glob
import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
import pandas as pd

# 示例输出路径（可根据实际情况修改）
output_path = f"era_data/1994_Page"

def viz_ERA_data(
    output_path,
    var_name=None,
    pressure_level=None,
    time_idx=0,
    proj=ccrs.PlateCarree(),
    figsize=(12, 8),
    cmap=None,
    save_fig=False,
    save_dir="era_plots"
):
    """
    可视化 ERA5 气压层数据（NetCDF 格式），支持多变量、多气压层、地图投影和批量保存

    参数：
        output_path (str): NetCDF 文件所在目录路径
        var_name (str, optional): 要可视化的变量名，可选值：
            't' (温度)、'z' (位势)、'u' (U风)、'v' (V风)、'q' (比湿)
            若为 None，自动显示所有可用变量供选择
        pressure_level (str/int, optional): 气压层（hPa），如 850、500
            若为 None，自动显示文件中所有可用气压层供选择
        time_idx (int, optional): 时间索引（默认取第一个时间点）
        proj (cartopy.crs, optional): 地图投影（默认：PlateCarree 等经纬度投影）
        figsize (tuple, optional): 图形大小（默认：(12, 8)）
        cmap (str, optional): 颜色映射（默认根据变量自动选择）
        save_fig (bool, optional): 是否保存图片（默认：False）
        save_dir (str, optional): 图片保存目录（默认：era_plots）
    """
    # ---------------------- 1. 查找并读取 NetCDF 文件 ----------------------
    nc_files = glob.glob(f"{output_path}/*.nc")
    if not nc_files:
        print(f"错误：在 {output_path} 目录下未找到 NetCDF 文件")
        return
    
    # 读取第一个文件（若有多个文件，可扩展为批量处理）
    nc_file = nc_files[0]
    print(f"正在读取文件：{os.path.basename(nc_file)}")
    ds = xr.open_dataset(nc_file)
    print(f"文件维度信息：{ds.dims}")

    # ---------------------- 2. 变量选择 ----------------------
    # 定义变量的中文名称和单位，便于显示
    var_info = {
        't': ('温度', '°C'),
        'z': ('位势高度', 'gpm'),
        'u': ('U分量风速', 'm/s'),
        'v': ('V分量风速', 'm/s'),
        'q': ('比湿', 'kg/kg')
    }
    
    # 筛选文件中实际存在的变量
    available_vars = [var for var in var_info.keys() if var in ds.variables]
    if not available_vars:
        print("错误：文件中未找到支持的变量")
        ds.close()
        return
    
    # 若未指定变量，让用户选择
    if var_name is None or var_name not in available_vars:
        print("\n可用变量列表：")
        for i, var in enumerate(available_vars, 1):
            print(f"  {i}. {var} - {var_info[var][0]}")
        choice = input(f"\n请输入要可视化的变量序号（1-{len(available_vars)}）：")
        try:
            var_idx = int(choice) - 1
            var_name = available_vars[var_idx]
        except (ValueError, IndexError):
            print("输入无效，默认选择第一个变量")
            var_name = available_vars[0]
    
    var_cn, var_unit = var_info[var_name]
    print(f"\n当前可视化变量：{var_name} - {var_cn} ({var_unit})")

    # ---------------------- 3. 气压层选择（仅对气压层变量） ----------------------
    available_levels = None
    if 'pressure_level' in ds.dims:
        available_levels = ds['pressure_level'].values.astype(str)
        print(f"文件中可用气压层（hPa）：{', '.join(available_levels)}")
        
        # 若未指定气压层，让用户选择
        if pressure_level is None:
            choice = input(f"\n请输入要可视化的气压层（hPa）：")
            while choice not in available_levels:
                print(f"无效气压层！可选值：{', '.join(available_levels)}")
                choice = input("请重新输入：")
            pressure_level = choice
        else:
            pressure_level = str(pressure_level)
            if pressure_level not in available_levels:
                print(f"警告：气压层 {pressure_level} 不存在，默认选择第一个气压层")
                pressure_level = available_levels[0]
    
    # ---------------------- 4. 数据提取与预处理 ----------------------
    # 提取数据（根据是否有气压层维度）
    if 'pressure_level' in ds.dims:
        data = ds[var_name].sel(pressure_level=pressure_level)
    else:
        data = ds[var_name]
    
    # jiancha
    print("数据维度:", data.dims)


    # 选择时间点
    if time_idx >= len(data.valid_time):
        print(f"警告：时间索引 {time_idx} 超出范围，默认选择最后一个时间点")
        time_idx = -1
    data = data.isel(valid_time=time_idx)
    
    # 数据单位转换
    if var_name == 't':
        data = data - 273.15  # K → °C
    elif var_name == 'z':
        data = data / 9.80665  # 位势 m²/s² → 位势高度 gpm
    elif var_name in ['u', 'v']:
        data = data  # 风速单位已为 m/s
    elif var_name == 'q':
        data = data  # 比湿单位已为 kg/kg

    # ---------------------- 5. 可视化配置 ----------------------
    # 自动选择颜色映射
    if cmap is None:
        if var_name in ['t', 'q']:
            cmap = 'YlOrRd' if var_name == 't' else 'Blues'
        elif var_name in ['u', 'v']:
            cmap = 'RdBu_r'
        elif var_name == 'z':
            cmap = 'terrain'

    # 创建图形
    fig, ax = plt.subplots(1, 1, figsize=figsize, subplot_kw={'projection': proj})
    
    # 添加地图特征
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), linewidth=0.8)
    ax.add_feature(cfeature.BORDERS.with_scale('50m'), linewidth=0.5, linestyle='--')
    ax.add_feature(cfeature.LAND, facecolor='lightgray', alpha=0.3)
    ax.gridlines(draw_labels=True, linestyle=':', alpha=0.7)

    # ---------------------- 6. 绘制数据 ----------------------
    # 绘制填充 contour
    im = data.plot(
        ax=ax,
        transform=ccrs.PlateCarree(),  # 数据的原始投影（经纬度）
        cmap=cmap,
        add_colorbar=True,
        cbar_kwargs={
            'shrink': 0.8,
            'pad': 0.02,
            'label': f'{var_cn} ({var_unit})'
        },
        alpha=0.8
    )

    # ---------------------- 7. 图形美化与标题 ----------------------
    # 获取时间信息
    time_str = pd.to_datetime(data.valid_time.values).strftime('%Y-%m-%d %HZ')
    
    # 构建标题
    title_parts = [
        f'ERA5 {var_cn}',
        f'气压层：{pressure_level} hPa' if pressure_level else '',
        f'时间：{time_str}'
    ]
    title = ' | '.join([part for part in title_parts if part])
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)

    # 调整布局
    plt.tight_layout()

    # ---------------------- 8. 保存图片 ----------------------
    if save_fig:
        os.makedirs(save_dir, exist_ok=True)
        # 构建文件名
        level_str = f'level{pressure_level}_' if pressure_level else ''
        fig_name = f'ERA5_{var_name}_{level_str}{time_str.replace(" ", "_").replace(":", "")}.png'
        fig_path = os.path.join(save_dir, fig_name)
        plt.rcParams['font.sans-serif'] = ['SimHei'] 
        plt.savefig(fig_path, dpi=300, bbox_inches='tight')
        print(f"图片已保存至：{fig_path}")

    # 不显示图形，直接保存
    plt.close(fig)
    ds.close()


def batch_viz_ERA_data(
    output_path,
    var_names=None,
    pressure_levels=None,
    time_indices=[0],
    **kwargs
):
    """
    批量可视化 ERA5 数据（多变量、多气压层、多时间点）

    参数：
        output_path (str): NetCDF 文件所在目录路径
        var_names (list, optional): 要批量可视化的变量列表（默认：所有可用变量）
        pressure_levels (list, optional): 要批量可视化的气压层列表（默认：所有可用气压层）
        time_indices (list, optional): 要可视化的时间索引列表（默认：[0]）
        **kwargs: 传递给 viz_ERA_data 的其他参数（如 proj、cmap、save_fig 等）
    """
    # 读取文件获取可用变量和气压层
    nc_files = glob.glob(f"{output_path}/*.nc")
    if not nc_files:
        print(f"错误：在 {output_path} 目录下未找到 NetCDF 文件")
        return
    
    ds = xr.open_dataset(nc_files[0])
    var_info = {'t': '温度', 'z': '位势高度', 'u': 'U风', 'v': 'V风', 'q': '比湿'}
    available_vars = [var for var in var_info.keys() if var in ds.variables]
    available_levels = ds['pressure_level'].values.astype(str) if 'pressure_level' in ds.dims else []
    
    # 确定批量处理的参数
    var_names = var_names if var_names and all(v in available_vars for v in var_names) else available_vars
    pressure_levels = pressure_levels if pressure_levels else available_levels
    if not pressure_levels:
        pressure_levels = [None]  # 处理无气压层的情况

    # 批量生成可视化
    print(f"\n开始批量可视化：{len(var_names)} 个变量 × {len(pressure_levels)} 个气压层 × {len(time_indices)} 个时间点")
    for var in var_names:
        for level in pressure_levels:
            for t_idx in time_indices:
                print(f"\n--- 正在可视化：{var_info[var]} | 气压层：{level} hPa | 时间索引：{t_idx} ---")
                viz_ERA_data(
                    output_path=output_path,
                    var_name=var,
                    pressure_level=level,
                    time_idx=t_idx,
                    **kwargs
                )
    ds.close()


# ---------------------- 测试使用示例 ------------------------------
if __name__ == "__main__":
    # 示例 1：基础使用（自动选择变量和气压层）
    # viz_ERA_data(output_path)

    # 示例 2：指定变量、气压层和投影，保存图片
    # viz_ERA_data(
    #     output_path=output_path,
    #     var_name='t',          # 温度
    #     pressure_level=850,    # 850 hPa 层
    #     time_idx=0,            # 第一个时间点
    #     proj=ccrs.Robinson(),  # 罗宾逊投影（更美观的全球投影）
    #     cmap='coolwarm',       # 冷暖色映射
    #     save_fig=True,         # 保存图片
    #     save_dir="era_plots/1994_Page"
    # )

    # 示例 3：批量可视化（多变量、多气压层）
    batch_viz_ERA_data(
        output_path=output_path,
        var_names=['t', 'z', 'u'],  # 批量可视化温度、位势、U风
        pressure_levels=['850', '500'],  # 批量可视化 850hPa 和 500hPa
        time_indices=[0, 1],  # 批量可视化前2个时间点
        proj=ccrs.PlateCarree(),
        save_fig=True,
        save_dir="era_plots/1994_Page_batch"
    )

    