def get_ERA_yearly_data(inputYear):
    
    import cdsapi

    dataset = "reanalysis-era5-pressure-levels"
    request = {
        "product_type": ["reanalysis"],
        "variable": [
            "geopotential",
            "temperature",
            "u_component_of_wind",
            "v_component_of_wind"
        ],
        "year": [f"{inputYear}"],
        "month": [
            "01", "02", "03",
            "04", "05", "06",
            "07", "08", "09",
            "10", "11", "12"
        ],
        "day": [
            "01", "02", "03",
            "04", "05", "06",
            "07", "08", "09",
            "10", "11", "12",
            "13", "14", "15",
            "16", "17", "18",
            "19", "20", "21",
            "22", "23", "24",
            "25", "26", "27",
            "28", "29", "30",
            "31"
        ],
        "time": ["00:00"],
        "pressure_level": [
            "100", "500", "850",
            "1000"
        ],
        "data_format": "grib",
        "download_format": "unarchived"
    }

    client = cdsapi.Client()
    client.retrieve(dataset, request).download()

    import os
    os.makedirs(f"era_data/{inputYear}", exist_ok=True)

    for file in os.listdir():
        if file.endswith(".grib"):
            os.rename(file, f"era_data/{inputYear}/{file}")

    return f"era_data/{inputYear} DONE"
