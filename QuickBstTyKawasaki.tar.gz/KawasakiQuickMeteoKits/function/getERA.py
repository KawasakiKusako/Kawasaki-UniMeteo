import pandas as pd
import os

from datetime import datetime


def choose_typhoon(typhoon_list, inputYear):
    """
    显示所有台风列表，让用户选择一个台风，并返回其起始和结束时间。
    
    Args:
        typhoon_list (pd.DataFrame): 包含台风编号、名称、起始和结束时间的DataFrame。
        inputYear (int): 当前处理的年份。

    Returns:
        tuple: (start_time_str, end_time_str, typhoon_name_str, typhoon_id_str, output_path)
    """

    typhoon_list_display = typhoon_list.copy()
    typhoon_list_display.reset_index(drop=False, inplace=True)
    typhoon_list_display.rename(columns={'index': 'Index'}, inplace=True)

    print(f"\n--- {inputYear} 年台风列表 ---")
    print(typhoon_list_display[['Index', 'TYPH', 'NAME', 'START', 'END']].to_string(index=False))
    print("-----------------------------\n")

    selected_index = -1
    selected_typhoon = None

    while True:
        try:
            
            input_index = input(f"请输入要选择的台风的 Index (0 到 {len(typhoon_list_display) - 1}): ")
            selected_index = int(input_index)

            if 0 <= selected_index < len(typhoon_list_display):
                selected_typhoon = typhoon_list_display.loc[selected_index]
                break
            else:
                print("输入的 Index 超出范围，请重新输入。")
        except ValueError:
            print("输入无效，请输入一个数字 Index。")
        except Exception as e:
            print(f"发生错误: {e}")
            
    # 提取
    typhoon_id = selected_typhoon['TYPH']
    typhoon_name = selected_typhoon['NAME']
    start_time = selected_typhoon['START']
    end_time = selected_typhoon['END']

    output_path = f"era_data/{inputYear}_{typhoon_name}"
    
    print(f"\n您选择的台风是: {typhoon_name} (编号: {typhoon_id})")
    print(f"该台风的数据时间范围是 (含前后 24 小时): {start_time} 至 {end_time}")

    return start_time, end_time, typhoon_name, typhoon_id, output_path

def get_ERA_data_old(start_time, end_time, inputYear, typhoon_name):
    """
    从 Copernicus Climate Data Store (CDS) 下载 ERA5 气压层数据（全球，用于初始场）。
    **频率：每天 2 次 (00Z 和 12Z)；层次：减少到 7 层。**
    
    **需要安装 cdsapi 库并配置账户凭证。**
    """
    try:
        import cdsapi
    except ImportError:
        print("错误: 请先安装 cdsapi 库 (pip install cdsapi)")
        return

    
    # 1. 设置输出路径和文件名
    safe_name = str(typhoon_name).replace(' ', '_').replace('/', '_')
    output_dir = f"era_data/{inputYear}_{safe_name}"
    os.makedirs(output_dir, exist_ok=True)
    output_filename = os.path.join(output_dir, f"ERA5_Global_PL_{inputYear}_{safe_name}_00_12Z.nc")
    
    # 2. 解析时间并生成请求所需的日期和小时列表
    start_dt = datetime.strptime(str(start_time), '%Y%m%d%H')
    end_dt = datetime.strptime(str(end_time), '%Y%m%d%H')
    
    date_range_days = pd.date_range(
        start=pd.Timestamp(start_dt).floor('D'), 
        end=pd.Timestamp(end_dt).ceil('D'), 
        freq='D'
    )

    # 提取年份、月份、日期列表
    years = list(date_range_days.year.unique().astype(str))
    months = [f'{m:02d}' for m in date_range_days.month.unique()]
    days = [f'{d:02d}' for d in date_range_days.day.unique()]
    
    # **修改 1: 设定每天两次（00:00 UTC 和 12:00 UTC）**
    times = ['00:00', '12:00'] 

    # 3. 定义气压层变量和层级
    variables = [
        'temperature',       # 温度 (T)
        'geopotential',       # 位势 (Z)
        'u_component_of_wind',   # U 分量风速
        'v_component_of_wind',   # V 分量风速
        'specific_humidity',    # 比湿 (Q)
    ]
    
    pressure_levels = [
        '1000', '850', '500', '100'
    ] 

    # 4. 构造请求参数
    request_data = {
        'product_type': 'reanalysis',
        'format': 'netcdf',
        'variable': variables,
        'pressure_level': pressure_levels,
        'year': years,
        'month': months,
        'day': days,
        'time': times,
        # **移除 'area' 参数以获取全球数据**
    }

    print(f"\n--- 开始下载 ERA5 全球气压层数据 ---")
    print(f"**已优化：时间步长为 00:00 UTC 和 12:00 UTC (每天 2 次)**")
    print(f"**已优化：气压层级减少到 {len(pressure_levels)} 层**")
    print(f"目标文件: {output_filename}")
    print(f"时间范围: {start_time} 至 {end_time}")
    print(f"气压层级: {', '.join(pressure_levels)} hPa")
    
    c = cdsapi.Client()
    try:
        c.retrieve(
            'reanalysis-era5-pressure-levels',
            request_data,
            output_filename
        )
        print("ERA5 数据下载完成！")
    except Exception as e:
        print(f"\n！！！ERA5 数据下载失败！！！")
        print(f"可能是因为时间范围仍然过长，或者 CDS 服务器繁忙。")
        print(f"错误信息: {e}")


def get_ERA_data(start_time, end_time, inputYear, typhoon_name):
    """
    从 Copernicus Climate Data Store (CDS) 下载 ERA5 气压层数据（全球，用于初始场）。
    **频率：每天 2 次 (00Z 和 12Z)；层次：7 层（优化后更全面的气压层配置）。**
    
    核心特性：
    - 时间分辨率：00:00 UTC 和 12:00 UTC（每天2次）
    - 气压层级：1000、925、850、700、500、300、100 hPa（7层，覆盖对流层到平流层底部）
    - 变量包含：温度、位势、风分量、比湿（气象模拟核心参数）
    - 数据格式：NetCDF（便于后续处理）
    - 空间范围：全球（无区域限制）
    
    **需要安装 cdsapi 库并配置账户凭证（~/.cdsapirc 文件）。**
    
    参数：
        start_time (str/int): 起始时间，格式为 YYYYMMDDHH（如 2023090100）
        end_time (str/int): 结束时间，格式为 YYYYMMDDHH（如 2023091012）
        inputYear (str/int): 目标年份（用于路径命名，需与时间范围一致）
        typhoon_name (str): 台风名称（用于路径和文件名标识）
    """
    # 检查 cdsapi 库是否安装
    try:
        import cdsapi
    except ImportError:
        print("错误: 请先安装 cdsapi 库 (pip install cdsapi)")
        return

    # 1. 路径配置与文件名生成（安全处理特殊字符）
    safe_name = str(typhoon_name).replace(' ', '_').replace('/', '_').replace('\\', '_')
    output_dir = f"era_data/{str(inputYear)}_{safe_name}"
    # 使用 os.path.join 确保跨平台兼容
    output_filename = os.path.join(
        output_dir, 
        f"ERA5_Global_PL_{str(inputYear)}_{safe_name}_00_12Z.nc"
    )
    os.makedirs(output_dir, exist_ok=True) # 放在这里确保目录存在

    # 2. 时间范围解析（兼容字符串/整数输入，自动处理日期范围）
    try:
        start_dt = datetime.strptime(str(start_time), '%Y%m%d%H')
        end_dt = datetime.strptime(str(end_time), '%Y%m%d%H')
    except ValueError:
        print("错误: 时间格式不正确！请使用 YYYYMMDDHH 格式（如 2023090100）")
        return

    # 生成完整日期范围（按天粒度，自动覆盖起始-结束区间）
    date_range_days = pd.date_range(
        start=pd.Timestamp(start_dt).floor('D'),
        end=pd.Timestamp(end_dt).ceil('D'),
        freq='D'
    )

    # 提取请求所需的年、月、日列表（自动去重，格式补零）
    years = [str(year) for year in date_range_days.year.unique()]
    months = [f"{month:02d}" for month in date_range_days.month.unique()]
    days = [f"{day:02d}" for day in date_range_days.day.unique()]
    times = ['00:00', '12:00'] # 每天2次，符合需求

    # 3. 核心请求参数配置（整合原始代码变量，扩展为7层气压）
    dataset = "reanalysis-era5-pressure-levels" # 原始代码数据集标识
    variables = [
        "geopotential",       # 位势
        "temperature",       # 温度
        "u_component_of_wind",   # 风场U分量
        "v_component_of_wind",   # 风场V分量
        "specific_humidity",    # 比湿
    ]
    pressure_levels = [
        "1000", "850", "700",    # 近地面-边界层
        "500",        # 中层大气
        "200", "100"        # 高层大气
    ]

    # 4. 构造CDS请求
    request = {
        "product_type": "reanalysis",
        "variable": variables,
        "year": years,
        "month": months,
        "day": days,
        "time": times,
        "pressure_level": pressure_levels,
        "format": "netcdf",      
    }

    # 5. 下载日志输出（清晰展示配置信息）
    print("\n" + "="*60)
    print("--- 开始下载 ERA5 全球气压层数据 ---")
    print("="*60)
    print(f"📅 时间配置：每天 2 次（{', '.join(times)} UTC）")
    print(f"🌪️ 气压层级：{len(pressure_levels)} 层（{', '.join(pressure_levels)} hPa）")
    
    # 修复变量列表显示，使其更简洁
    display_vars = [v.split('_')[0] if v in ['u_component_of_wind', 'v_component_of_wind'] else v for v in variables]
    display_vars = [v.replace('specific', 'specific_humidity') for v in display_vars] # 保持比湿完整
    print(f"📊 变量列表：{', '.join(display_vars)}")
    
    print(f"🗺️ 空间范围：全球数据")
    print(f"📁 输出文件：{output_filename}")
    print(f"⏳ 时间区间：{start_time} → {end_time}")
    print(f"📦 数据集：{dataset}")
    print("="*60)

    # 6. 执行下载（修复 API 调用错误）
    client = cdsapi.Client()
    try:
        client.retrieve(
            dataset, # 修复：将数据集名称作为第一个位置参数
            request, # 第二个位置参数
            output_filename # 第三个位置参数
        )
        print(f"\n✅ ERA5 数据下载完成！文件已保存至：{output_filename}")
    except Exception as e:
        error_msg = str(e).strip()
        print("\n❌ ERA5 数据下载失败！")
        print("可能原因及解决方案：")
        print("1. 时间范围过长 → 拆分时间区间（建议单次≤7天）")
        print("2. 网络问题 → 检查网络连接，重试下载")
        print("3. 凭证配置错误 → 检查 ~/.cdsapirc 文件是否正确配置")
        print("4. 服务器繁忙 → 稍后重试（CDS服务器高峰期可能限流）")
        print(f"\n详细错误信息：{error_msg}")

def select_ERA_data(start_time, end_time, inputYear, typhoon_name):
    """
    从 Copernicus Climate Data Store (CDS) 下载 ERA5 气压层数据（全球，用于初始场）。
    **频率：每天 2 次 (00Z 和 12Z)；层次：减少到 7 层。**
    
    **需要安装 cdsapi 库并配置账户凭证。**
    """
    # 由于该函数内容与 get_ERA_data 几乎重复，直接调用 get_ERA_data 以避免重复代码
    get_ERA_data(start_time, end_time, inputYear, typhoon_name)
    
if __name__ == '__main__':
    # 这是一个示例调用，需要一个包含台风信息的 DataFrame 来运行 choose_typhoon
    # 假设你已经定义了 typhoon_data
    # data = {
    #     'TYPH': ['9401', '9402'], 
    #     'NAME': ['Ira', 'Tim'], 
    #     'START': [1994050200, 1994071500], 
    #     'END': [1994051012, 1994072212]
    # }
    # typhoon_list_example = pd.DataFrame(data)
    # 
    # try:
    #     start, end, name, tid, path = choose_typhoon(typhoon_list_example, 1994)
    #     get_ERA_data(start, end, 1994, name)
    # except Exception as e:
    #     print(f"Demo run failed: {e}")
    
    pass