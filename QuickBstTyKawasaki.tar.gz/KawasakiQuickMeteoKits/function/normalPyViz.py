# 通过上面返回的df，绘制台风路径图

df = read_typhoon_data(inputYear)
def plot_typhoon_path(df):
    import matplotlib.pyplot as plt
    plt.figure(figsize=(10, 6))
    plt.plot(df['LON'], df['LAT'], marker='o', linestyle='-')
    plt.title(f'{inputYear}年台风路径')
    plt.xlabel('经度')
    plt.ylabel('纬度')
    plt.grid(True)
    plt.show()