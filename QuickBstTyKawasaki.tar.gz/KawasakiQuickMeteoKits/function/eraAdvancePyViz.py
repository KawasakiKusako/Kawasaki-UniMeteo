def plot_era5_visualization(start_time, end_time, inputYear, typhoon_name):
    import xarray as xr
    import matplotlib.pyplot as plt
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
    import cartopy.io.shapereader as shpreader
    import numpy as np
    import os

    # --- Shapefile 路径定义 (请替换为您的实际文件路径) ---
    #CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/nation/国界_Project.shp' # 中国国标国界线 Shapefile
    #CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/world/World_Country.shp' # 

    CHINA_BOUNDARY_SHP = 'extraRepo/SHP/china_SHP/nation/省界_Project.shp' # 中国国标国界线 Shapefile
    SOUTH_CHINA_SEA_SHP = 'extraRepo/SHP/china_SHP/southSea/南海诸岛及其它岛屿.shp' # 南海诸岛 Shapefile


    # --- 1. 配置和加载数据 ---
    file_path = f'era_data/{inputYear}_{typhoon_name}/ERA5_Global_PL_{inputYear}_{typhoon_name}_00_12Z.nc'
    try:
        ds = xr.open_dataset(file_path)
        ds = ds.rename({'valid_time': 'time'})
        print("Data loaded successfully.")
    except FileNotFoundError:
        print(f"Error: File not found at '{file_path}'. Please check the path.")
        exit()

    time_index = 0
    data_time_str = ds['time'].isel(time=time_index).dt.strftime('%Y/%m/%d %HZ').item()
    EAST_ASIA_EXTENT = [70, 140, 15, 55] 

    # --- 2. 准备绘图数据 ---
    data_subset = ds.isel(time=time_index).sel(
        latitude=slice(EAST_ASIA_EXTENT[3], EAST_ASIA_EXTENT[2]),
        longitude=slice(EAST_ASIA_EXTENT[0], EAST_ASIA_EXTENT[1])
    )

    Z500 = data_subset['z'].sel(pressure_level=500, method='nearest') / 9.80665 
    T850 = data_subset['t'].sel(pressure_level=850, method='nearest') - 273.15
    U850 = data_subset['u'].sel(pressure_level=850, method='nearest')
    V850 = data_subset['v'].sel(pressure_level=850, method='nearest')


    # --- 3. 绘制图形 ---

    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(1, 1, 1, projection=ccrs.Mercator(central_longitude=105))


    ax.set_extent(EAST_ASIA_EXTENT, crs=ccrs.PlateCarree())

    try:
        ax.add_feature(cfeature.LAND, facecolor='lightgray', alpha=0.5)
    except AttributeError:
        pass 

    # **修改 2: 增加世界地图的shp（半透明）**
    try:
        # 使用  naturalearth_lowres 低分辨率国界线
        world_borders = cfeature.BORDERS.with_scale('110m') 
        #ax.add_feature(world_borders, edgecolor="#00000066", linewidth=0.3)
    except AttributeError:
        print("!!! 警告: 无法加载 naturalearth_lowres Shapefile，跳过绘制世界半透明边界。")

    try:
        #绘制naturalearth_lowres海岸线
        ax.coastlines(resolution='50m', linewidth=0.8, color='k') 
        ax.add_feature(world_borders, edgecolor="#000000B9", linewidth=0.3)
    except AttributeError:
        print("!!! 警告: 无法加载 naturalearth_lowres Shapefile，跳过绘制世界半透明边界。")

    # 绘制中国国标国界线
    if os.path.exists(CHINA_BOUNDARY_SHP):
        reader = shpreader.Reader(CHINA_BOUNDARY_SHP)
        for geometry in reader.geometries():
            ax.add_geometries([geometry], ccrs.PlateCarree(),
                            facecolor='none', edgecolor='k', linewidth=1.0)
    else:
        print("!!! 警告: 未找到国标 Shapefile，使用默认的 Cartopy 海岸线和边界。")
        ax.coastlines(resolution='50m', linewidth=0.8, color='k') 
        try:
            ax.add_feature(cfeature.BORDERS, linestyle=':', alpha=0.8, edgecolor='k')
        except AttributeError:
            pass


    # 绘制经纬度网格和标签
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True, 
                    linewidth=0.5, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False 
    gl.right_labels = False
    gl.x_inline = False 
    gl.xlabel_style = {'size': 10, 'color': 'gray'}
    gl.ylabel_style = {'size': 10, 'color': 'gray'}


    # --- 绘制 850 hPa 温度填色/等值线 ---
    temp_levels = np.arange(-45, 48, 3) 
    '''
    cf = ax.contourf(T850.longitude, T850.latitude, T850, 
                    levels=temp_levels, cmap='coolwarm', extend='both', 
                    transform=ccrs.PlateCarree())
    '''
    import matplotlib.colors as mcolors
    colors = [
        "#FFE1F2",
        "#F030EA",  # -36°C
        '#C03090',  # -30°C
        '#9030C0',  # -24°C
        '#6030F0',  # -18°C
        '#3060F0',  # -12°C
        '#3090F0',  # -6°C
        '#30C0C0',  # 0°C（中性色）
        '#60F090',  # 3°C
        '#C0F030',  # 9°C
        '#FFD030',  # 15°C
        '#FF9030',  # 21°C
        '#FF3040',  # 27°C
        '#FF6080',  # 33°C
        '#FFA0C0',  # 39°C
        '#FFE0F0'   # 45°C（最热）
    ]
    custom_cmap = mcolors.LinearSegmentedColormap.from_list('custom_thermometer', colors, N=150)
    temp_levels = np.arange(-45, 48, 3)
    norm = mcolors.BoundaryNorm(temp_levels, ncolors=custom_cmap.N, clip=False)

    temp_levels = np.arange(-45, 48, 3) 
    cf = ax.contourf(T850.longitude, T850.latitude, T850, 
                    levels=temp_levels, cmap=custom_cmap, extend='both', 
                    transform=ccrs.PlateCarree())

    cbar = fig.colorbar(cf, ax=ax, orientation='vertical', pad=0.03, shrink=0.7, label='Temperature ($\mathrm{^\circ C}$)')
    cbar.set_ticks(np.arange(-45, 48, 3))

    temp_contour_levels = np.arange(-50, 50, 10)
    cs_temp_light = ax.contour(T850.longitude, T850.latitude, T850, 
                            levels=temp_contour_levels, colors='silver', linewidths=0.5, linestyles='-', 
                            transform=ccrs.PlateCarree())
    ax.clabel(cs_temp_light, inline=True, fontsize=7, fmt='%.0f', colors='silver')

    cs0c = ax.contour(T850.longitude, T850.latitude, T850, 
                    levels=[0], colors='white', linewidths=2.0, linestyles='-', 
                    transform=ccrs.PlateCarree())
    ax.clabel(cs0c, inline=True, fontsize=10, fmt='0$\mathrm{^\circ C}$', colors='white')


    # --- 绘制 500 hPa 位势高度 ---
    levels_500 = np.arange(5160, 5940, 40)
    cs500 = ax.contour(Z500.longitude, Z500.latitude, Z500, 
                        levels=levels_500, colors='k', linewidths=0.8, 
                        transform=ccrs.PlateCarree())
    ax.clabel(cs500, inline=True, fontsize=8, fmt='%d', colors='k')

    if 5880 in levels_500:
        cs5880 = ax.contour(Z500.longitude, Z500.latitude, Z500, 
                            levels=[5880], colors='r', linewidths=2.5, 
                            transform=ccrs.PlateCarree())
        ax.clabel(cs5880, inline=True, fontsize=10, fmt='5880', colors='r')


    # --- 绘制 850 hPa 风矢量 ---
    skip = 3
    Q = ax.quiver(U850.longitude[::skip], U850.latitude[::skip], 
                U850.values[::skip, ::skip], V850.values[::skip, ::skip], 
                color='white', 
                scale=1000, width=0.0012, headwidth=3.5, headlength=4.5,
                transform=ccrs.PlateCarree())


    # **执行南海小图绘制**,外围加上白色边框
    # 1. 检查 Shapefile 是否存在
    scs_shapefile = SOUTH_CHINA_SEA_SHP

    if not os.path.exists(scs_shapefile):
            # 尝试使用 cartopy 默认的低分辨率边界作为南海小图的底图
            print(f"!!! 警告: 找不到南海诸岛 Shapefile: {scs_shapefile}. 跳过绘制九段线，仅绘制简化底图。")
            draw_scs_features = False
    else:
            draw_scs_features = True

        # 2. 创建南海小图的 Axes
        # [left, bottom, width, height]
    ax_scs = fig.add_axes([0.07, 0.15, 0.1, 0.2], projection=ccrs.PlateCarree()) 
        
        # 3. 设置小图范围和底图
    ax_scs.set_extent([105, 122, 0, 25], crs=ccrs.PlateCarree())
    ax_scs.axis('off') # 关闭坐标轴
    ax_scs.set_frame_on(True)
    ax_scs.patch.set_edgecolor('black')
    ax_scs.patch.set_linewidth(1.5)
        
        # 4. 绘制地图要素（简化）
    ax_scs.add_feature(cfeature.LAND, facecolor='lightgray')
    ax_scs.add_feature(cfeature.OCEAN, facecolor='white')
    ax_scs.coastlines(resolution='50m', linewidth=0.5, color='k')
        
        # 5. 绘制南海诸岛和九段线 (如果文件存在)
    if draw_scs_features:
        try:
            reader = shpreader.Reader(scs_shapefile)
            for geometry in reader.geometries():
                ax_scs.add_geometries([geometry], ccrs.PlateCarree(),
                                        facecolor='none', edgecolor='k', linewidth=0.5)
        except Exception as e:
                print(f"!!! 警告: 读取南海 Shapefile 失败: {e}")


    # --- 标题 (左上角) ---
    ax.set_title(
        f"ERA-5 850mb Temperature (shaded, °C), Wind (vector) & 500mb Geopotential Height (contour)\n"
        f"Historical Data : {data_time_str} valid at {data_time_str}   CDUT CMS @Kawasaki Kusako ", 
        loc='left', fontsize=12, color='dimgray'
    )

    # 调整布局
    plt.tight_layout()
    plt.savefig(f"{inputYear}_{typhoon_name}_.png", dpi=300, bbox_inches='tight')
    plt.close()