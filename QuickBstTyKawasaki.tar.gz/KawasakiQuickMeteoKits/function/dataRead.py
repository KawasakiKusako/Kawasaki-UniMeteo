import pandas as pd
from datetime import datetime, timedelta
import os

def read_typhoon_data(inputYear):
    # 读取 /dataSet 目录下的 **** 年份的台风数据
    filepath = f"dataSet/CH{inputYear}BST.txt"
    all_typhoon_data = []
    current_typhoon_id = None
    current_typhoon_name = None

    try:
        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue

                # 1. 识别台风信息头 (Typhoon Header Block)，例如 '66666 0000 36 0001 9401 0 6 Owen ...'
                if line.startswith('66666'):
                    parts = line.split()
                    if len(parts) > 4:
                        # 台风编号 (TYPH) 位于第 5 个字段 (parts[4])
                        current_typhoon_id = parts[4]
                        
                        # 台风名称 (NAME) 位于编号之后的字段，需要更精确的提取
                        # 找到 ID 之后的部分，然后去掉最后的日期
                        name_start_index = line.find(current_typhoon_id) + len(current_typhoon_id)
                        try:
                           # 截取 ID 之后的部分，用空格分割，取最后一个分割块（包含名称和日期）
                           start_of_name_and_date = line[name_start_index:].strip().split(' ', 2)
                           name_and_date_str = start_of_name_and_date[-1]
                           # 从名称+日期字符串中，去除日期，得到名称
                           current_typhoon_name = name_and_date_str.rsplit(' ', 1)[0].strip()
                        except IndexError:
                           current_typhoon_name = f"TYPHOON_{current_typhoon_id}"

                # 2. 识别台风路径数据行 (Track Data Line)
                # 路径数据行以 10 位时间戳开头，例如 '1994033112'
                elif line.startswith('19') and len(line) >= 10 and current_typhoon_id is not None:
                    track_parts = line.split()
                    # 路径数据行至少应包含时间、类型、纬度、经度、气压、风速 6 个字段
                    if len(track_parts) >= 6:
                        data = {
                            'TIME': track_parts[0], # 时间 'YYYYMMDDHH'
                            'TYPH': current_typhoon_id,
                            'NAME': current_typhoon_name,
                            # 仅保留所需的列，如果您需要其他数据（如纬度、经度等），请在此处添加
                        }
                        all_typhoon_data.append(data)

        # 转换为数据框
        df = pd.DataFrame(all_typhoon_data)
        
        # 将 TIME 列转换为 datetime 对象，以便进行时间运算
        df['TIME'] = pd.to_datetime(df['TIME'], format='%Y%m%d%H', errors='coerce')
        df = df.dropna(subset=['TIME']) # 移除时间解析失败的行

        # 打印数据前五行
        #print(df.head())
        # 返回数据框
        return df

    except FileNotFoundError:
        print(f"错误: 找不到文件 {filepath}")
        return pd.DataFrame()


def get_typhoon_list(inputYear,df):
    # 确保 DataFrame 不为空
    if df.empty:
        print("DataFrame 为空，无法生成台风列表。")
        return pd.DataFrame(columns=['TYPH', 'NAME', 'START', 'END'])
    
    # 定义24小时的 timedelta
    one_day = timedelta(hours=24)
    
    # 按 'TYPH' 和 'NAME' 分组，找到每个台风的最小和最大时间
    typhoon_summary = df.groupby(['TYPH', 'NAME'])['TIME'].agg(['min', 'max']).reset_index()

    typhoon_list = []
    for index, row in typhoon_summary.iterrows():
        first_time = row['min']
        last_time = row['max']
        
        # 根据要求计算起始和结束时间
        # 每个台风的起始时间为 24 小时前的时间
        start_time = first_time - one_day
        # 每个台风的结束时间为 24 小时后的时间
        end_time = last_time + one_day
        
        # 将 datetime 对象转换回 'YYYYMMDDHH' 格式的字符串
        typhoon_list.append([
            row['TYPH'], 
            row['NAME'], 
            start_time.strftime('%Y%m%d%H'), 
            end_time.strftime('%Y%m%d%H')
        ])
        
    # 转换为数据框
    typhoon_list_df = pd.DataFrame(typhoon_list, columns=['TYPH', 'NAME', 'START', 'END'])
    
    # 确保 cache 目录存在
    os.makedirs('cache', exist_ok=True)
    
    # 输出到 cache/typhoon_list_{inputYear}.csv
    csv_filename = f"cache/typhoon_list_{inputYear}.csv"
    typhoon_list_df.to_csv(csv_filename, index=False)
    #print(f"台风列表已保存到 {csv_filename}")

    # 修正原代码中写入 .txt 文件的错误逻辑
    # 原代码的循环 `for typhoon in typhoon_list:` 遍历的是列名，而不是数据行。
    txt_filename = f"cache/typhoon_list_{inputYear}.txt"
    with open(txt_filename, "w", encoding='utf-8') as f:
        # 写入标题行
        f.write("台风编号,台风名称,台风起始时间,台风结束时间\n")
        # 写入数据行
        for index, row in typhoon_list_df.iterrows():
            f.write(f"{row['TYPH']},{row['NAME']},{row['START']},{row['END']}\n")
    print(f"台风列表已保存到 {txt_filename}")
    
    # 打印数据前五行
    #print(typhoon_list_df.head())
    # 返回数据框
    return typhoon_list_df
