import csv
import os


def extract_cyclone_data(txt_path, output_dir):
    #创建输出文件夹（若不存在）
    os.makedirs(output_dir, exist_ok=True)

    #读取txt文件内容
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = [line.strip() for line in f if line.strip()]  # 去除空行和首尾空格

    #定义变量：存储当前气旋信息、CSV表头
    current_cyclone = None  # 存储当前气旋的编号和数据列表
    cyclone_header = [
        "time", "strength", "latitude", "longitude", "pressure", "WND", "OWD"
    ]

    #遍历所有行，提取气旋信息
    for line in lines:
        #识别气旋标识行（以"66666 0000"开头，包含编号和名称）
        if line.startswith("66666 0000"):
            #若存在上一个未处理的气旋，先写入CSV
            if current_cyclone is not None:
                cyclone_id, cyclone_name, cyclone_data = current_cyclone
                write_to_csv(cyclone_id, cyclone_name, cyclone_data, cyclone_header, output_dir)

            #提取当前气旋编号和名称
            line_parts = line.split()
            cyclone_id = line_parts[3]  # 气旋编号固定在标识行第4个位置
            cyclone_name = line_parts[7]  # 气旋名称固定在标识行第8个位置
            current_cyclone = (cyclone_id, cyclone_name, [])  # 初始化当前气旋的数据列表

        # 识别气旋路径数据行（以1987开头，代表1987年的时间戳,是纪录数据时间
        elif line.startswith("1987"):
            if current_cyclone is not None:
                #解析数据行："time", "strength", "latitude", "longitude", "pressure", "WND", "OWD"
                cyclone_data = [
                    line[0:11],  # 时间戳
                    line[11:13],  # 强度
                    line[13:17],  # 纬度
                    line[17:22],  # 经度
                    line[22:27],  # 气压
                    line[32:35],  # 最大风速
                    line[37:40],  # 最大风向
                ]
                current_cyclone[2].append(cyclone_data)  # 将数据添加到当前气旋的数据列表中

    #处理最后一个气旋
    if current_cyclone is not None:
        cyclone_id, cyclone_name, cyclone_data = current_cyclone
        write_to_csv(cyclone_id, cyclone_name, cyclone_data, cyclone_header, output_dir)


def write_to_csv(cyclone_id, cyclone_name, cyclone_data, cyclone_header, output_dir):
    #创建CSV文件，文件名格式为"id_name.csv"
    csv_path = os.path.join(output_dir, f"{cyclone_id}_{cyclone_name}.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(cyclone_header)
        writer.writerows(cyclone_data)


#txt路径以及存储路径
txt_file_path = "dataSet/CH1994BST.txt"
output_folder = "dataSet/processed"

# 执行数据提取
if __name__ == "__main__":
    # 检查txt文件是否存在
    if not os.path.exists(txt_file_path):
        print(f"错误：未找到txt文件，请检查路径：{txt_file_path}")
    else:
        extract_cyclone_data(txt_file_path, output_folder)


import os
import pandas as pd
import numpy as np

def clean_cyclone_data(input_dir="dataSet/processed", output_dir="dataSet/cleaned"):
    """
    读取data文件夹中的所有CSV文件，进行数据清洗，并保存到cleaned_data文件夹
    
    参数:
        input_dir: 输入文件夹路径
        output_dir: 输出文件夹路径
    """
    # 创建输出文件夹（若不存在）
    os.makedirs(output_dir, exist_ok=True)
    
    # 获取所有CSV文件
    csv_files = [f for f in os.listdir(input_dir) if f.endswith('.csv')]
    
    for csv_file in csv_files:
        # 读取CSV文件
        file_path = os.path.join(input_dir, csv_file)
        df = pd.read_csv(file_path)
        
        # 数据清洗步骤
        # 1. 去除前后空格
        df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
        
        # 2. 处理缺失值（使用新的ffill()方法替代fillna(method='ffill')）
        df = df.ffill()
        
        # 3. 转换数据类型
        df['time'] = pd.to_datetime(df['time'], format='%Y%m%d%H%M')
        df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce') / 10  # 转换为实际纬度
        df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce') / 10  # 转换为实际经度
        df['pressure'] = pd.to_numeric(df['pressure'], errors='coerce')  # 转换为数值
        df['WND'] = pd.to_numeric(df['WND'], errors='coerce')  # 最大风速
        df['OWD'] = pd.to_numeric(df['OWD'], errors='coerce')  # 最大风向
        
        # 4. 去除异常值（这里简单示例，可根据实际需求调整）
        df = df[(df['pressure'] > 800) & (df['pressure'] < 1200)]  # 合理气压范围
        df = df[(df['WND'] >= 0) & (df['WND'] <= 300)]  # 合理风速范围
        df = df[(df['latitude'] >= -90) & (df['latitude'] <= 90)]  # 合理纬度范围
        df = df[(df['longitude'] >= -180) & (df['longitude'] <= 180)]  # 合理经度范围
        
        # 5. 重置索引
        df.reset_index(drop=True, inplace=True)
        
        # 保存清洗后的数据
        output_path = os.path.join(output_dir, csv_file)
        df.to_csv(output_path, index=False)
        print(f"已清洗并保存: {output_path}")

if __name__ == "__main__":
    # 检查输入文件夹是否存在
    if not os.path.exists("dataSet/processed"):
        print("错误：未找到dataSet/processed文件夹，请先运行数据处理.ipynb生成数据")
    else:
        clean_cyclone_data()

import pandas as pd
import os
import folium
from folium.plugins import AntPath
from branca.colormap import linear

# 确保读取的是清洗后的数据文件夹
data_folder = 'dataSet/cleaned'
output_folder = 'dataSet/output'

# 创建输出文件夹
if not os.path.exists(output_folder):
    os.makedirs(output_folder)


def read_all_csv_files(folder_path):
    all_data = []
    for file_name in os.listdir(folder_path):
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            try:
                data = pd.read_csv(file_path)
                if 'latitude' in data.columns and 'longitude' in data.columns:
                    all_data.append(data)
                else:
                    print(f"警告：文件 {file_name} 缺少必要的列（latitude/longitude）")
            except Exception as e:
                print(f"读取文件 {file_name} 时出错: {e}")
    return all_data


# 读取所有 CSV 文件
all_cyclone_data = read_all_csv_files(data_folder)

if not all_cyclone_data:
    print("错误：没有读取到有效的气旋数据！请检查数据文件夹和文件内容。")
else:
    # 修复：在计算平均经纬度之前，先过滤掉可能包含NaN的DataFrame
    valid_data = []
    for df in all_cyclone_data:
        # 确保经纬度列存在且不为空
        if 'latitude' in df.columns and 'longitude' in df.columns:
            # 转换为数值类型并移除NaN
            df['latitude'] = pd.to_numeric(df['latitude'], errors='coerce')
            df['longitude'] = pd.to_numeric(df['longitude'], errors='coerce')
            # 检查是否还有有效数据
            if not df[['latitude', 'longitude']].isna().all().all():
                valid_data.append(df)
    
    # 如果有有效数据，则计算平均经纬度
    if valid_data:
        avg_lat = sum(df['latitude'].mean() for df in valid_data) / len(valid_data)
        avg_lon = sum(df['longitude'].mean() for df in valid_data) / len(valid_data)
    else:
        # 如果没有有效数据，使用默认坐标（例如亚洲中部）
        print("警告：所有数据都包含无效的经纬度！使用默认坐标。")
        avg_lat, avg_lon = 35.0, 105.0
    
    # 再次检查是否还有NaN
    if pd.isna(avg_lat) or pd.isna(avg_lon):
        print("警告：计算的平均坐标包含NaN！使用默认坐标。")
        avg_lat, avg_lon = 35.0, 105.0

    # 创建地图，使用深色底图
    m = folium.Map(
        location=[avg_lat, avg_lon], 
        zoom_start=4,
        tiles='CartoDB dark_matter',  # 使用深色底图
        control_scale=True,
        prefer_canvas=True  # 提高性能
    )
    
    # 添加一个荧光蓝的渐变色条作为图例（可选）
    colormap = linear.PuBu_09.scale(0, 1)
    colormap.caption = '气旋路径强度'
    m.add_child(colormap)

    # 遍历每个气旋数据并添加路径到地图
    for cyclone_data in all_cyclone_data:
        # 确保经纬度数据是数值类型
        cyclone_data['latitude'] = pd.to_numeric(cyclone_data['latitude'], errors='coerce')
        cyclone_data['longitude'] = pd.to_numeric(cyclone_data['longitude'], errors='coerce')
        cyclone_data = cyclone_data.dropna(subset=['latitude', 'longitude'])  # 移除无效坐标

        if not cyclone_data.empty:
            path = list(zip(cyclone_data['latitude'], cyclone_data['longitude']))

            # 修改AntPath参数，使用荧光蓝路径
            AntPath(
                path,
                color='#00FFFF',  # 荧光蓝
                weight=5,  # 增加线宽
                opacity=0.9,  # 设置透明度
                dash_array=None,  # 移除虚线效果
                delay=800,  # 动画延迟
                pulse_color='#00FFFF',  # 动画脉冲颜色
                pulse_interval=1000  # 脉冲间隔
            ).add_to(m)

    # 保存地图
    map_file_path = os.path.join(output_folder, 'cyclone_paths_map_dark.html')
    m.save(map_file_path)
    print(f"地图已成功保存到: {os.path.abspath(map_file_path)}")

    print(f"共读取到 {len(all_cyclone_data)} 个气旋数据文件") 
    for i, df in enumerate(all_cyclone_data):     
        print(f"气旋 {i+1} 有 {len(df)} 个路径点")     
    print(df[['latitude', 'longitude']].head())